<?php $__env->startSection('title', 'Post'); ?>
<?php $__env->startSection('content'); ?>
 <!-- ======= Breadcrumbs ======= -->
    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2><?php echo e($post->titre); ?></h2>
          <ol>
            <li><a href="<?php echo e(url('/')); ?>">Accueil</a></li>
            <li><a href="<?php echo e(route('boutique')); ?>">Retour</a></li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->

    <!-- ======= Blog Section ======= -->
        <section id="blog" class="blog">
      <div class="container">

        <div class="row">

          <div class="col-lg-8 entries">

            <article class="entry entry-single" data-aos="fade-up">

              <div class="entry-img">
                <img src="<?php echo e(asset("public/storage/".$post->images)); ?>" alt="" class="img-fluid">
              </div>

              <h2 class="entry-title">
                <a href="blog-single.html"><?php echo e($post->titre); ?></a>
              </h2>

              <div class="entry-meta">
                <ul>
                  <li class="d-flex align-items-center"><i class="icofont-user"></i> <a href="">Publié par <?php echo e(DB::table('users')->where('id',$post->users_id)->first()->name); ?></a></li>
                  <li class="d-flex align-items-center"><i class="icofont-wall-clock"></i> <a href=""><time datetime="2020-01-01">Publié le <?php echo e($post->date2); ?></time></a></li>
                </ul>
              </div>

              <div class="entry-content">
                <p style="line-height:2;">
                  <?php echo e($post->contenu); ?>

                </p>
              </div>

              <div class="entry-footer clearfix">
                <div class="float-left">
                </div>

                <div class="float-right share">
                  <a href="" title="Share on Twitter"><i class="icofont-twitter"></i></a>
                  <a href="" title="Share on Facebook"><i class="icofont-facebook"></i></a>
                  <a href="" title="Share on Instagram"><i class="icofont-instagram"></i></a>
                </div>

              </div>
			  </div>

          <div class="col-lg-4">

            <div class="sidebar" data-aos="fade-left">
              <h3 class="sidebar-title">Opérateurs récents</h3>
              <div class="sidebar-item recent-posts">
				<?php $__currentLoopData = $pub2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pub3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="post-item clearfix">
                  <img src="<?php echo e(asset("public/storage/".$pub3->images)); ?>" alt="" class="img-fluid">
                  <h4><a href="<?php echo e(route('post', ['id'=>$pub3->id])); ?>"><?php echo e($pub3->titre); ?></a></h4>
                  <time datetime="2020-01-01"><?php echo e($pub3->date2); ?></time>
                </div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </div><!-- End sidebar recent posts-->

              <!-- End sidebar tags-->

            </div><!-- End sidebar -->

          </div><!-- End blog sidebar -->

        </div>

      </div>
    </section><!-- End Blog Section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/c1302473c/public_html/dunamisdegabon.com/resources/views/post.blade.php ENDPATH**/ ?>