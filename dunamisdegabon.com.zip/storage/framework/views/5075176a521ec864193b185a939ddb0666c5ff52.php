<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <!-- CSRF Token -->
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title><?php echo $__env->yieldContent('title'); ?> - Dunamis Development Gabon</title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="<?php echo e(asset('img/favicon.jpg')); ?>" rel="icon">
  <link href="<?php echo e(asset('img/favicon.jpg')); ?>" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<?php echo e(asset('assets/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('assets/vendor/icofont/icofont.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('assets/vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('assets/vendor/animate.css/animate.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('assets/vendor/venobox/venobox.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('assets/vendor/owl.carousel/assets/owl.carousel.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('assets/vendor/aos/aos.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('assets/vendor/remixicon/remixicon.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('toastr/toastr.min.css')); ?>" rel="stylesheet" type="text/css" />
  <!-- Template Main CSS File -->
  <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Company - v2.0.0
  * Template URL: https://bootstrapmade.com/company-free-html-bootstrap-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">

      <h3 class="logo mr-auto" style="font-size:14px;">
		<?php if(session('user')->roles == "Admin"): ?> 
            <a href="<?php echo e(route('tableau_de_bord')); ?>"><img src="<?php echo e(asset('assets/img/logo.jpg')); ?>" class="img-fluid"/></a>
		<?php elseif(session('user')->roles == "Client"): ?> 
		    <a href="<?php echo e(route('tableaudebord')); ?>"><img src="<?php echo e(asset('assets/img/logo.jpg')); ?>" class="img-fluid"/></a>
		<?php else: ?>
			<a href="<?php echo e(route('tb_de_bord')); ?>"><img src="<?php echo e(asset('assets/img/logo.jpg')); ?>" class="img-fluid"/></a>
		<?php endif; ?>
	  </h3>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo mr-auto"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

         <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li class="active">
		  </li>
		  <li class="drop-down"><a href="">	
            MENU
		  </a>
            <ul>
			<?php if(session('user')->roles == "Admin"): ?> 
			<li><a href="<?php echo e(route('liste-des-inscriptions')); ?>">Liste des inscriptions</a></li>
		<li><a href="<?php echo e(route('liste_des_demandes')); ?>">Liste des demandes</a></li>
           <li><a href="<?php echo e(route('nouveau_pub')); ?>">Enregistrer une pub</a></li>
		<li><a href="<?php echo e(route('entreprise')); ?>">Enregistrer une Entreprise</a></li>
		<li><a href="<?php echo e(route('abonnement')); ?>">Enregistrer un abonnement</a></li>
		  <li><a href="<?php echo e(route('nouveau_pub')); ?>">Toutes les pub</a></li>
		  <li><a href="<?php echo e(route('liste_des_entreprises')); ?>">Liste des entreprises</a></li>
		  <li><a href="<?php echo e(route('liste_des_clients')); ?>">Liste des clients</a></li>
		  <li><a href="<?php echo e(route('liste_des_abonnements')); ?>">Clients abonnés</a></li>
		  <li><a href="<?php echo e(route('ajouter_projet')); ?>">Nouveau projet</a></li>
			<?php endif; ?>
			<?php if(session('user')->roles == "Entreprise"): ?> 
              <li><a href="<?php echo e(route('achat')); ?>">Enregistrer un achat</a></li>
			<?php endif; ?>
			<?php if(session('user')->roles == "Entreprise"): ?> 
              <li><a href="<?php echo e(route('ajouter-catalogue')); ?>">Enregistrer une image catalogue</a></li>
			<a href="<?php echo e(route('liste_des_achats')); ?>">Liste des achats enregistrés</a>
			<?php endif; ?>
			<li><a href="<?php echo e(route('reinit')); ?>">Réinitialiser mon mot de passe</a></li>
			  <li>
				<form method="post" action="<?php echo e(route('Deconnexion')); ?>">
				<?php echo e(csrf_field()); ?>

				<button class="btn btn-default" type="submit" style="margin-left:10px;font-size:14px;font-weight:700;width:100%;">
				 Déconnexion
				</button>
				</form>
			  <li>
			  </li>
            </ul>
          </li>
        </ul>
      </nav>
		<div class="header-social-links">
        <a href="#" class="twitter"><i class="icofont-user"></i> 
		Bienvenue 
			<?php if(session('user')->roles == "Admin"): ?> 
			<?php echo e(session('user')->name); ?>

			<?php elseif(session('user')->roles == "Client"): ?> 
			<?php echo e(DB::table('compte')->where('users_id',session('user')->id)->first()->nom); ?>

			<?php else: ?>
			<?php echo e(session('user')->name); ?>

			<?php endif; ?>
		</a>
      </div>
    </div>
  </header><!-- End Header -->
  

  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
   <!-- End Breadcrumbs -->

    <!-- ======= Services Section ======= -->
   
    <?php echo $__env->yieldContent('content'); ?>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="container d-md-flex py-4">

      <div class="mr-md-auto text-center text-md-left">
        <div class="copyright">
          &copy; Copyright <strong><span>DUNAMIS DEVELOPMENT GABON</span></strong>. Tous droits reservés.
        </div>
        <div class="credits">
          <!-- All the links in the footer should remain intact. -->
          <!-- You can delete the links only if you purchased the pro version. -->
          <!-- Licensing information: https://bootstrapmade.com/license/ -->
          <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/company-free-html-bootstrap-template/ -->
          Réalisé par <a href="https://kbe-technologies.com">KBE TECHNOLOGIES</a>
        </div>
      </div>
      <div class="social-links text-center text-md-right pt-3 pt-md-0">
        <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
        <a target="_blank" href="https://fb.me/dunamisdegabon" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
        <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
        <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

  <!-- Vendor JS Files -->
  <script src="<?php echo e(asset('assets/vendor/jquery/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/vendor/jquery.easing/jquery.easing.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/vendor/jquery-sticky/jquery.sticky.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/vendor/isotope-layout/isotope.pkgd.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/vendor/venobox/venobox.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/vendor/waypoints/jquery.waypoints.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/vendor/owl.carousel/owl.carousel.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/vendor/aos/aos.js')); ?>"></script>
<script src="<?php echo e(asset('toastr/toastr.min.js')); ?>"></script>
  <!-- Template Main JS File -->
  <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
  <?php echo $__env->yieldPushContent('scripts'); ?>

</body>

</html><?php /**PATH /home/c1302473c/public_html/dunamisdegabon.com/resources/views/layout2.blade.php ENDPATH**/ ?>