<?php $__env->startComponent('mail::message'); ?>
# Hey Admin

- <?php echo e($nom); ?>

- <?php echo e($email); ?>

- <?php echo e($sujet); ?>

- <?php echo e($msg); ?>


Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\projets\SiteWeb\resources\views/emails/messages/created.blade.php ENDPATH**/ ?>