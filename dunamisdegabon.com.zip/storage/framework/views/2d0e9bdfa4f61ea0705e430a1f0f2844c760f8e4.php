<?php $__env->startSection('title', 'Opérateurs de la Plateforme E-dunamis'); ?>
<?php $__env->startSection('content'); ?>
 <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Opérateurs de la Plateforme E-dunamis</h2>
          <ol>
            <li><a href="<?php echo e(url('/')); ?>">Accueil</a></li>
            <li>Opérateurs de la Plateforme E-dunamis</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->
	
    <!-- ======= Blog Section ======= -->
    <section id="blog" class="blog" style="background-color:#fff;">
      <div class="container">

        <div class="row">
          <div class="col-lg-8 entries">
	  <h3 align="left" style="color:blue;"></h3><br/>
	        <div class="row">
			<?php $__currentLoopData = $pub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pubs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-lg-6">
            <article class="entry" data-aos="fade-up">

              <div class="entry-img">
			  <img src="<?php echo e(asset("public/storage/".$pubs->images)); ?>" alt="" class="img-fluid"/>
               <!-- <img src="assets/img/blog-1.jpg" alt="" class="img-fluid">-->
              </div>

              <h2 class="entry-title">
                <a href="blog-single.html"><?php echo e($pubs->titre); ?></a>
              </h2>

              <div class="entry-meta">
                <ul>
                  <li class="d-flex align-items-center"><i class="icofont-user"></i> <a href=""><?php echo e(DB::table('users')->where('id',$pubs->users_id)->first()->name); ?></a></li>
                  <li class="d-flex align-items-center"><i class="icofont-wall-clock"></i> <a href=""><time datetime="2020-01-01"><?php echo e($pubs->date2); ?></time></a></li>
                </ul>
              </div>

              <div class="entry-content">
                <p>
                  
                </p>
                <div class="read-more">
                  <a href="<?php echo e(route('post', ['id'=>$pubs->id])); ?>" style="text-align:center">En savoir plus</a>
                </div>
              </div>

            </article><!-- End blog entry -->
            </div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="blog-pagination">
              <?php echo e($pub->links()); ?>

            </div>

          </div><!-- End blog entries list -->

          <div class="col-lg-4">

            <div class="sidebar" data-aos="fade-left">
              <h3 class="sidebar-title">Opérateurs récents</h3>
              <div class="sidebar-item recent-posts">
				<?php $__currentLoopData = $pub2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pub3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="post-item clearfix">
                  <img src="<?php echo e(asset("public/storage/".$pub3->images)); ?>" alt="">
                  <h4><a href="blog-single.html"><?php echo e($pub3->titre); ?></a></h4>
                  <time datetime="2020-01-01"><?php echo e($pub3->date2); ?></time>
                </div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </div><!-- End sidebar recent posts-->

              <!-- End sidebar tags-->
				 <br/>
	 <p align="center"><button class="btn btn-warning"><a href="<?php echo e(route('inscription-operateur')); ?>" style="color:#fff;">Voulez-vous rejoindre la plateforme des commerçants? Inscrivez-vous!</a></button></p>
            </div><!-- End sidebar -->

          </div><!-- End blog sidebar -->

        </div>
		<br/>
	
      </div>
    </section><!-- End Blog Section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/c1302473c/public_html/dunamisdegabon.com/resources/views/liste_des_pub.blade.php ENDPATH**/ ?>