<?php $__env->startSection('title','Liste des opérateurs '); ?>
<?php $__env->startSection('content'); ?>
<!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Liste des opérateurs</h2>
          <ol>
            <li>
			<?php if(session('user')->roles == "Admin"): ?> 
            <a href="<?php echo e(route('tableau_de_bord')); ?>">Tableau de bord</a>
		<?php elseif(session('user')->roles == "Client"): ?> 
		    <a href="<?php echo e(route('tableaudebord')); ?>">Tableau de bord</a>
		<?php else: ?>
			<a href="<?php echo e(route('tb_de_bord')); ?>">Tableau de bord</a>
		<?php endif; ?>
			</li>
            <li>Liste des opérateurs</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->
	     <section id="features" class="features">
      <div class="container" data-aos="fade-up">

        <div class="row">
	<?php if(session('status')): ?>
		<div class="col-lg-12">
            <div class="alert alert-warning" style="font-size: 15px; background-color: #328039; color: white">
                <i class="fa fa-warning"></i> <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger" style="font-size: 15px; background-color: #fb5757; color: white">
                <i class="ti-na"></i> <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger" style="font-size: 15px; background-color: #fb5757; color: white" >
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li> <i class="ti-na"></i> <?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
			</div>
        <?php endif; ?>
		
	<div class="col-lg-12 card">
	        <br>
			<h2 align="center">
             Liste des opérateurs
            </h2>
			 <br>
            <div class="table-responsive table-hover container">
				<table class="table">
				    <thead>
						<tr>
							<th width="220px">N°</th>
							<th width="220px">Raison sociale</th>
							<th width="220px">Représentant</th>
							<th width="300px">Email</th>
							<th width="300px">Forme juridique</th>
							<th width="300px">Téléphone</th>
							<th width="300px">Domaine</th>
							<th width="300px">Statut</th>
							<th width="300px">Actions</th>
						</tr>
					</thead>
					<tbody>
					<?php $__currentLoopData = $operateur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operateurs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
					<td><?php echo e($loop->iteration); ?></td>
					<td><?php echo e($operateurs->raison_sociale); ?></td>
					<td><?php echo e($operateurs->nom_rep); ?></td>
					<td><?php echo e($operateurs->email); ?></td>
					<td><?php echo e($operateurs->forme_juridique); ?></td>
					<td><?php echo e($operateurs->telephone); ?></td>
					<td><?php echo e($operateurs->domaine); ?></td>
					<td><?php echo e($operateurs->etat); ?></td>
					<td><a target="_blank" href="<?php echo e(route('ficheoperateur', ['id'=>$operateurs->id])); ?>"><i class="fa fa-info"></i> Voir fiche</a>&nbsp;&nbsp;
					<?php if($operateurs->etat=="Non actif"): ?>
					<a href="#" data-placement="bottom"  data-toggle="tooltip" title="Valider compte" class="data-valider" data-id="<?php echo e($operateurs->id); ?>"><i class="fa fa-check"></i>Activer compte</a>&nbsp;&nbsp;
					<?php endif; ?>
					</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>	
            </div>
			<div class="blog-pagination">
              <?php echo e($operateur->links()); ?>

            </div>
	</div>
	      </div>
		  <div class="modal fade bd-example-modal-sm" id="Validermodal">
			<div class="modal-dialog modal-sm">
				<div class="modal-content">
					<div class="modal-body">
						<p>Etes-vous sûr de vouloir valider cette inscription ?<br/>
						Cela stipule qu'un compte sera généré automatiquement pour cet opérateur
						</p>
					</div>
					<div class="modal-footer" style="background-color:#ffffff" id="valider">
	
					</div>
				</div>
			</div>
	</div>
    </section>
	<?php $__env->startPush('scripts'); ?>
	<script>

           

            $(".data-valider").on('click', function () {
                    var id=$(this).data('id');
                    $.get('Operateurs/'+id, function (data) {
                    
                        var html = ` 
                        
                        <button type="button" class="btn btn-sm btn btn-primary" data-dismiss="modal">Non</button>
                            <form action="<?php echo e(route('validercompte')); ?>" method="post" style="display: inline">
                                    <?php echo e(csrf_field()); ?>

                                            <input type="hidden" value="`+data.operateurs.id+`" name="id" >
                            <button type="submit" class="btn btn-sm btn btn-danger">Oui</button>

                        </form>`
                        ;

                        $('#valider').html('').append(html);

                    })
                    $('#Validermodal').modal();
                });

    
    
    </script>
	<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/c1302473c/public_html/dunamisdegabon.com/resources/views/liste-des-operateurs.blade.php ENDPATH**/ ?>