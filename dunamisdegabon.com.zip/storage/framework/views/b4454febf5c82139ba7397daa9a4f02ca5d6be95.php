<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta content="width=device-width, initial-scale=1.0" name="viewport">
	<link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link href="assets/css/style.css" rel="stylesheet">
  <title>Fiche d'inscription</title>
  </head>

<body style="background-color:#fff;">
	<div class="row">
		<div class="col-lg-12">
			<h1 class="logo mr-auto" align="center"><img src="assets/img/logo.jpg" class="img-fluid"/></h1>
		</div>
		<br/>
		<div class="col-lg-12" style="margin-top:140px;">
			<h3 class="logo mr-auto ph4" align="center">FORMULAIRE D'ENREGISTREMENT CONSULTANT</h3>
		</div>
		<div class="container">
		<div class="col-lg-12" style="margin-top:250px;">
			<table style="margin-left:-100px;width:650px;" class="table">
				<tr><td style="width:165px"><b>NOM :</b></td><td style="width:150px"><?php echo e($inscrip->nom); ?></td><td style="width:150px"><b>EMAIL :</b></td><td><?php echo e($inscrip->email); ?></td></tr>
				<tr><td><b>DATE DE NAISSANCE :</b></td><td><?php echo e($inscrip->datenais); ?></td><td><b>TÉLÉPHONE :</b></td><td><?php echo e($inscrip->telephone); ?></td></tr>
				<tr><td><b>ADRESSE :</b></td><td colspan="3"><?php echo e($inscrip->adresse); ?></td></tr>
				<tr><td><b>NATIONALITÉ :</b></td><td colspan="3"><?php echo e($inscrip->nationalite); ?></td></tr>
				<tr><td><b>COMPÉTENCES :</b></td><td colspan="3"><?php echo e($inscrip->competence); ?></td></tr>
				<tr><td><b>LANGUES :</b></td><td colspan="3"><?php echo e($inscrip->langue); ?></td></tr>
				<tr><td><b>EXPÉRIENCE :</b></td><td colspan="3"><?php echo e($inscrip->experience); ?></td></tr>
			</table>
		</div>
		</div>
		</div>
		<div class="row">
		<div class="container">
		<h5 align="center">Travaux illustrant le mieux mes principales compétences</h5>
		<div class="col-lg-12" style="display:block;position:absolute;margin-top:40px;">
			<table style="margin-left:-120px;width:700px;" class="table">
				<tr><td style="width:80px"><b>CLIENT</b></td><td style="width:100px"><b>MISSION</b></td><td style="width:130px"><b>ACTIVITÉ PRINCIPALE</b></td><td style="width:80px"><b>PERTINENTE</b></td><td style="width:10px"><b>DATE/ANNÉE/LIEU</b></td></tr>
				<?php $__currentLoopData = $travaux; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $travau): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
				<td><?php echo e($travau->client); ?></td>
				<td><?php echo e($travau->mission); ?></td>
				<td><?php echo e($travau->activite_principale); ?></td>
				<td><?php echo e($travau->pertinente); ?></td>
				<td><?php echo e($travau->date_travaux); ?>/ <?php echo e($travau->lieu); ?></td>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tr>
				
			</table>
		</div>
		
		<div class="col-lg-12" style="display:block;position:relative;margin-top:300px;margin-left:-80px;">
		Fait  à  <?php echo e($inscrip->ville); ?>, le <?php echo e($inscrip->dateins); ?> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Signature
		</div>
		
		</div>
		</div>
		
	

</body>
</html><?php /**PATH C:\projets\SiteWeb\resources\views/fiche_inscription_consultant.blade.php ENDPATH**/ ?>