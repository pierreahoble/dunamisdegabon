<?php $__env->startSection('title', 'Ajouter une publication'); ?>
<?php $__env->startSection('content'); ?>
 <!-- ======= Breadcrumbs ======= -->
   <!-- End Breadcrumbs -->
    <section id="contact" class="contact">
      <div class="container">

        <div class="row mt-5 justify-content-center" data-aos="fade-up">
          <div class="col-lg-6">
		  <div style="background-color:#fff;padding:15px;">
		  <h3 align="center">Ajouter une nouvelle publication</h3>
		  </div>
		  <?php if(session('status')): ?>
				<div class="alert alert-success" style="font-size: 15px; background-color: #328039; color: white">
					<i class="ti-check"></i> <?php echo e(session('status')); ?>

				</div>
			<?php endif; ?>

			<?php if(session('error')): ?>
				<div class="alert alert-danger" style="font-size: 15px;color: white">
					<i class="ti-na"></i> <?php echo e(session('error')); ?>

				</div>
			<?php endif; ?>
			
			<br/>
		    <form method="post" action="<?php echo e(route('pubPost')); ?>" role="form" class="php-email-form" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

			<br/>
              <div class="form-row">
			  
				<div class="col-md-12 form-group">
				<label class="label-control">Sélectionner l'entreprise</label>
                  <select class="form-control" name="entreprise_id" required>
						<option value="">Sélectionner l'entreprise</option>
						<?php $__currentLoopData = $entreprises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entreprise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($entreprise->id); ?>"><?php echo e($entreprise->name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
                </div>
				<div class="col-md-12 form-group">
				<label class="label-control">Catégorie</label>
                  <select class="form-control" name="categories_id" required>
						<option value="">Sélectionner une catégorie</option>
						<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($categorie->id); ?>"><?php echo e($categorie->libelle); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
                </div>
				<div class="col-md-12 form-group">
				<label class="label-control">Sélectionner une image de mise en avant</label>
                  <input type="file" class="form-control" name="image" required>
                </div>
                <div class="col-md-12 form-group">
				<label class="label-control">Titre de la publication</label>
                  <input id="titre" type="text" class="form-control" name="titre" placeholder="Veuillez saisir le titre" required>
				  <div class="validate"></div>
                </div>
                <div class="col-md-12 form-group">
				<label class="label-control">Contenu de la publication</label>
                  <textarea class="form-control" name="contenu" rows="10" data-rule="required" data-msg="Veuillez saisir le contenu"></textarea>
				  <div class="validate"></div>
                </div>
				<div class="col-md-6 form-group">
							<button type="reset" class="btn btn-danger" style="width:100%;">
                                    Annuler
                            </button>
							</div>
							<div class="col-md-6 form-group">
							<button type="submit" class="btn btn-primary" style="width:100%;">
                                    Enregistrer
                            </button>
							</div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section><!-- End Contact Section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projets\SiteWeb\resources\views/nouveau_pub.blade.php ENDPATH**/ ?>