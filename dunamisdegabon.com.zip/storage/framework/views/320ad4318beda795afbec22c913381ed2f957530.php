<?php $__env->startSection('title', 'Réinitialiser mot de passe'); ?>
<?php $__env->startSection('content'); ?>
 <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbss">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Réinitialiser mot de passe</h2>
          <ol>
            <li>
			<?php if(session('user')->roles == "Admin"): ?> 
            <a href="<?php echo e(route('tableau_de_bord')); ?>">Tableau de bord</a>
		<?php elseif(session('user')->roles == "Client"): ?> 
		    <a href="<?php echo e(route('tableaudebord')); ?>">Tableau de bord</a>
		<?php else: ?>
			<a href="<?php echo e(route('tb_de_bord')); ?>">Tableau de bord</a>
		<?php endif; ?>
			</li>
            <li>Réinitialiser mot de passe</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->
    <section id="contact" class="contact">
      <div class="container">
        <div class="row mt-5 justify-content-center" data-aos="fade-up">
          <div class="col-lg-6">
		  <?php if(session('status')): ?>
				<div class="alert alert-success" style="font-size: 15px; background-color: #328039; color: white">
					<i class="ti-check"></i> <?php echo e(session('status')); ?>

				</div>
			<?php endif; ?>

			<?php if(session('error')): ?>
				<div class="alert alert-danger" style="font-size: 15px;color: white">
					<i class="ti-na"></i> <?php echo e(session('error')); ?>

				</div>
			<?php endif; ?>
		  <h3 align="center">Réinitialiser le mot de passe</h3>
		  <br/>
		    <form method="post" action="<?php echo e(route('reinitPost')); ?>" role="form" class="php-email-form">
            <?php echo e(csrf_field()); ?>

			<br/>
              <div class="form-row">
                <div class="col-md-12 form-group">
                  <input id="password1" type="password" class="form-control" name="password1" placeholder="Veuillez saisir le nouveau mot de passe" required>
				  <div class="validate"></div>
                </div>
                <div class="col-md-12 form-group">
                  <input type="password" class="form-control" name="password2" placeholder="Veuillez confirmer le nouveau mot de passe" required>
				  <div class="validate"></div>
                </div>
				<div class="col-md-12 form-group">
							<button type="submit" class="btn btn-primary" style="width:100%;">
                                    Se connecter
                            </button>
							</div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section><!-- End Contact Section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/c1302473c/public_html/dunamisdegabon.com/resources/views/reinit.blade.php ENDPATH**/ ?>