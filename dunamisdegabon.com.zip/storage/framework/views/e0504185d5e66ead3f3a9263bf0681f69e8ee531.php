<?php $__env->startSection('title', 'Authentification'); ?>
<?php $__env->startSection('content'); ?>
 <!-- ======= Breadcrumbs ======= -->
    <!-- End Breadcrumbs -->
    <section id="contact" class="contact">
      <div class="container">
		  <br/>
		  <br/>
	  <div style="background-color:#fff;padding:15px;">
		  <h3 align="center"><i class="icofont-unlock"></i> Connexion</h3>
		  </div>
		  <br/>
		<form method="post" action="<?php echo e(route('ConnexionPost')); ?>" role="form" class="php-email-form">
            <?php echo e(csrf_field()); ?>

        <div class="row" data-aos="fade-up">
			<div class="col-lg-6">
				<img src="<?php echo e(asset('img/login.jpg')); ?>" class="img-fluid" style="border-radius:80px;">
			</div>
          <div class="col-lg-6">
		  <?php if(session('status')): ?>
				<div class="alert alert-success" style="font-size: 15px; background-color: #328039; color: white">
					<i class="ti-check"></i> <?php echo e(session('status')); ?>

				</div>
			<?php endif; ?>

			<?php if(session('error')): ?>
				<div class="alert alert-danger" style="font-size: 15px;color: white">
					<i class="ti-na"></i> <?php echo e(session('error')); ?>

				</div>
			<?php endif; ?>
		    
			<br/>
              <div class="form-row">
                <div class="col-md-12 form-group">
					<label class="label-control"><b>Votre email</b></label>
                  <input id="email" type="email" class="form-control" name="email" placeholder="Veuillez saisir votre email" required>
				  <div class="validate"></div>
                </div>
                <div class="col-md-12 form-group">
					<label class="label-control"><b>Mot de passe</b></label>
                  <input type="password" class="form-control" name="password" placeholder="Veuillez saisir le mot de passe" required>
				  <div class="validate"></div>
                </div>
				<div class="col-md-12 form-group">
							<button type="submit" class="btn btn-primary" style="width:100%;">
                                    <i class="icofont-unlocked"></i> Se connecter
                            </button>
							</div>
              </div>
			  <div class="form-group row">
							
							<div class="col-md-12 form-group" style="text-align:center;">
								<p style="text-align:center;"><center>Vous n'avez pas de compte? <a href="<?php echo e(url('sinscrire')); ?>" style="color:red;"> <b>S'inscrire <i class="icofont-login"></i> </b></a></center></p>
							</div>
							
                </div>
            </form>
          </div>
			
        </div>
        </div>
      </div>
    </section><!-- End Contact Section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/c1302473c/public_html/dunamisdegabon.com/resources/views/login.blade.php ENDPATH**/ ?>