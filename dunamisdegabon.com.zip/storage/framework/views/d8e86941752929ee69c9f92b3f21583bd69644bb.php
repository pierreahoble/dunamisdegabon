<?php $__env->startSection('title', 'Opérateur info'); ?>
<?php $__env->startSection('content'); ?>
 <!-- ======= Breadcrumbs ======= -->
    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2><?php echo e($operateur->raison_sociale); ?></h2>
          <ol>
            <li><a href="<?php echo e(url('/')); ?>">Accueil</a></li>
            <li><a href="<?php echo e(route('plateforme-affaire')); ?>">Retour</a></li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->

    <!-- ======= Blog Section ======= -->
        <section id="blog" class="blog">
      <div class="container">

        <div class="row">

          <div class="col-lg-8 entries">

            <article class="entry entry-single" data-aos="fade-up">

              <div class="entry-img">
                <img src="<?php echo e(asset("public/storage/".$operateur->fichier)); ?>" alt="" class="img-fluid" style="height:400px;width:600px;">
              </div>

              <h2 class="entry-title">
                <a href="blog-single.html"><i class="icofont-ui-home"></i> Nom de l'entreprise : <?php echo e($operateur->raison_sociale); ?></a>
              </h2>

              <div class="entry-meta">
                <ul>
                  <li class="d-flex align-items-center"><i class="icofont-location-pin"></i> <a href=""><b>Adresse :</b> <?php echo e($operateur->adresse); ?></a></li><br/>
                  <li class="d-flex align-items-center"><i class="icofont-ui-cell-phone"></i> <a href=""><b>Téléphone :</b> <?php echo e($operateur->telephone); ?></a></li><br/>
                  <li class="d-flex align-items-center"><i class="icofont-wall-clock"></i> <a href=""><time datetime="2020-01-01"><b>Inscrit le</b> <?php echo e($operateur->dateins); ?></time></a></li>
                </ul>
              </div>

              <div class="entry-content">
                <p style="line-height:2;">
                  <b><i class="icofont-briefcase-2"></i> Nos services/produits/prestations : </b><br/><?php echo e($operateur->description); ?>

                </p>
              </div>

              <div class="entry-footer clearfix">
                <div class="float-left">
                </div>

                <div class="float-right share">
                  <a href="" title="Share on Twitter"><i class="icofont-twitter"></i></a>
                  <a href="" title="Share on Facebook"><i class="icofont-facebook"></i></a>
                  <a href="" title="Share on Instagram"><i class="icofont-instagram"></i></a>
                </div>

              </div>
              <br/>
              <section id="portfolio" class="portfolio">
                  <div class="container">
                      <div class="section-title">
                      <h2>Notre catalogue</h2>
                      <p>Images de nos produits ou promotions.</p>
                    </div>
                  <div class="row portfolio-container">
                    <?php $__currentLoopData = $catalogue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catalogue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-4 portfolio-item">
                  <img src="<?php echo e(asset("public/storage/".$catalogue->fichier)); ?>" alt="" class="img-fluid" style="height:200px;width:200px;">
                  <div class="portfolio-info">
              <center>
                  <a href="<?php echo e(url("public/storage/".$catalogue->fichier)); ?>" data-gall="portfolioGallery" class="venobox preview-link" title="Agrandir" style="text-align:center;"><i class="bx bx-plus"></i></a>
                  </center>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        </div>
        </section>

			  </div>

          <div class="col-lg-4">

            <div class="sidebar" data-aos="fade-left">
              <h3 class="sidebar-title">Opérateurs récents</h3>
              <div class="sidebar-item recent-posts">
				<?php $__currentLoopData = $operateur2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operateur2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="post-item clearfix">
                  <img src="<?php echo e(asset("public/storage/".$operateur2->fichier)); ?>" alt="" class="img-fluid">
                  <h4><a href="<?php echo e(route('operateur-info', ['id'=>$operateur2->id])); ?>"><?php echo e($operateur2->raison_sociale); ?></a></h4>
                  <time datetime="2020-01-01"><?php echo e($operateur2->dateins); ?></time>
                </div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </div><!-- End sidebar recent posts-->

              <!-- End sidebar tags-->

            </div><!-- End sidebar -->

          </div><!-- End blog sidebar -->

        </div>

      </div>
    </section><!-- End Blog Section -->
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/c1302473c/public_html/dunamisdegabon.com/resources/views/operateur-info.blade.php ENDPATH**/ ?>