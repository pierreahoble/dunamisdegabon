<?php $__env->startSection('title', 'Liste des inscriptions'); ?>
<?php $__env->startSection('content'); ?>
 <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbss">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Liste des inscriptions</h2>
          <ol>
            <li><a href="<?php echo e(url('/choix-profil')); ?>">Accueil</a></li>
            <li>Liste des inscriptions</li>
          </ol>
        </div>

      </div>
    </section>
    <section id="contact" class="contact">
      <div class="container">

        <div class="row mt-5 justify-content-center" data-aos="fade-up">
          <div class="col-lg-6">
		  <?php if(session('status')): ?>
				<div class="alert alert-success" style="font-size: 15px; background-color: #328039; color: white">
					<i class="ti-check"></i> <?php echo e(session('status')); ?>

				</div>
			<?php endif; ?>

			<?php if(session('error')): ?>
				<div class="alert alert-danger" style="font-size: 15px;color: white">
					<i class="ti-na"></i> <?php echo e(session('error')); ?>

				</div>
			<?php endif; ?>
		        <div class="form-row">
				
				<div class="col-md-12 form-group">
				<a href="<?php echo e(route('liste-des-consultants')); ?>" type="button" class="btn btn-danger" style="width:100%;">
						LISTE DES CONSULTANTS
				</a>
				</div>
				<div class="col-md-12 form-group">
				<a href="<?php echo e(route('liste-des-partenaires')); ?>" type="button" class="btn btn-primary" style="width:100%;">
						LISTE DES PARTENAIRES
				</a>
				</div>
				<div class="col-md-12 form-group">
				<a href="<?php echo e(route('liste-des-operateurs')); ?>" type="button" class="btn btn-warning" style="width:100%;">
						LISTE DES OPÉRATEURS
				</a>
				</div>	
              </div>
          </div>
        </div>
      </div>
    </section><!-- End Contact Section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projets\dunamisdegabon.com\resources\views/liste-des-inscriptions.blade.php ENDPATH**/ ?>