<?php $__env->startSection('title', 'Paiement bonus'); ?>
<?php $__env->startSection('content'); ?>
 <!-- ======= Breadcrumbs ======= -->
 <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbss">
      <div class="container">
        <div class="d-flex justify-content-between align-items-center">
          <h2><i class="icofont-money-bag" style="font-size:25px;"></i> Paiement bonus</h2>
          <ol>
            <li><?php if(session('user')->roles == "Admin"): ?> 
            <a href="<?php echo e(route('tableau_de_bord')); ?>"><i class="icofont-reply-all" style="font-size:25px;"></i> Retourner au tableau de bord</a>
			<?php elseif(session('user')->roles == "Client"): ?> 
		    <a href="<?php echo e(route('tableaudebord')); ?>"><i class="icofont-reply-all" style="font-size:25px;"></i> Retourner au tableau de bord</a>
			<?php else: ?>
			<a href="<?php echo e(route('tb_de_bord')); ?>"><i class="icofont-reply-all" style="font-size:25px;"></i> Retourner au tableau de bord</a>
			<?php endif; ?></li>
            <li>Tableau de bord</li>
          </ol>
        </div>
      </div>
    </section><!-- End Breadcrumbs -->
   <!-- End Breadcrumbs -->
    <section id="contact" class="contact">
      <div class="container">
		<div style="background-color:#fff;padding:15px;margin-top:-45px;">
		  <h3 align="center"><i class="icofont-money-bag"></i> Paiement bonus</h3>
		  </div>
		  <form method="post" action="<?php echo e(route('paiement-post', ['id'=>$id])); ?>" role="form" class="php-email-form" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

			<br/>
        <div class="row mt-2 justify-content-center" data-aos="fade-up">
          <div class="row col-lg-10">
          <div class="col-lg-5">
		  <?php if(session('status')): ?>
				<div class="alert alert-success" style="font-size: 15px; background-color: #328039; color: white">
					<i class="ti-check"></i> <?php echo e(session('status')); ?>

				</div>
			<?php endif; ?>

			<?php if(session('error')): ?>
				<div class="alert alert-danger" style="font-size: 15px;color: white;background-color:red;">
					<i class="ti-na"></i> <?php echo e(session('error')); ?>

				</div>
			<?php endif; ?>
			
			<br/>
		    
              <div class="form-row">
                <div class="col-md-12 form-group">
				<label class="label-control">Nom du client</label>
				<?php
					$nom = DB::table('compte')->where('id', $id)->first()->nom;
					$prenom = DB::table('compte')->where('id', $id)->first()->prenoms;
				?>
                  <input id="code_client" type="text" class="form-control" value="<?php echo e($nom); ?> <?php echo e($prenom); ?>" placeholder="Veuillez saisir le code du client" readOnly>
				  <div class="validate"></div>
                </div>
				<div class="col-md-12 form-group">
				<label class="label-control">Montant</label>
                  <input id="montant" type="text" class="form-control" name="montant" placeholder="Veuillez saisir le montant" required>
				  <div class="validate"></div>
                </div>
				<div class="col-md-6 form-group">
							<button type="reset" class="btn btn-danger" style="width:100%;">
                                    <i class="icofont-reply-all"></i> Annuler
                            </button>
							</div>
							<div class="col-md-6 form-group">
							<button type="submit" class="btn btn-primary" style="width:100%;">
                                    <i class="icofont-tick-mark"></i> Enregistrer
                            </button>
							</div>
              </div>
            </form>
          </div>
		  <div class="col-lg-5">
			<img src="<?php echo e(asset('img/operateur.jpg')); ?>" class="img-fluid" style="border-radius:80px;">
          </div>
          </div>
        </div>
      </div>
    </section><!-- End Contact Section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projets\dunamisdegabon.com\resources\views/paiement.blade.php ENDPATH**/ ?>