<?php $__env->startSection('title', 'Authentification'); ?>
<?php $__env->startSection('content'); ?>
 <!-- ======= Breadcrumbs ======= -->
    <!-- End Breadcrumbs -->
    <section id="contact" class="contact">
      <div class="container">

        <div class="row mt-5 justify-content-center" data-aos="fade-up">
          <div class="col-lg-6">
		  <div style="background-color:#fff;padding:15px;">
		  <h3 align="center">Connexion</h3>
		  </div>
		  <br/>
		  <?php if(session('status')): ?>
				<div class="alert alert-success" style="font-size: 15px; background-color: #328039; color: white">
					<i class="ti-check"></i> <?php echo e(session('status')); ?>

				</div>
			<?php endif; ?>

			<?php if(session('error')): ?>
				<div class="alert alert-danger" style="font-size: 15px;color: white">
					<i class="ti-na"></i> <?php echo e(session('error')); ?>

				</div>
			<?php endif; ?>
		    <form method="post" action="<?php echo e(route('ConnexionPost')); ?>" role="form" class="php-email-form">
            <?php echo e(csrf_field()); ?>

			<br/>
              <div class="form-row">
                <div class="col-md-12 form-group">
                  <input id="email" type="email" class="form-control" name="email" placeholder="Veuillez saisir votre email" required>
				  <div class="validate"></div>
                </div>
                <div class="col-md-12 form-group">
                  <input type="password" class="form-control" name="password" placeholder="Veuillez saisir le mot de passe" required>
				  <div class="validate"></div>
                </div>
				<div class="col-md-12 form-group">
							<button type="submit" class="btn btn-primary" style="width:100%;">
                                    Se connecter
                            </button>
							</div>
							<div class="col-md-12 form-group" style="text-align:center;">
								<p style="text-align:center;"><center><a style="width:100%;" class="btn btn-primary" href="<?php echo e(route('dashbord')); ?>"> Retour</a></center></p>
							</div>
              </div>
			  
            </form>
          </div>
        </div>
      </div>
    </section><!-- End Contact Section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout4', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/c1302473c/public_html/dunamisdegabon.com/resources/views/login2.blade.php ENDPATH**/ ?>