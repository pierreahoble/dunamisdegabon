<?php $__env->startSection('title','Tableau de bord'); ?>
<?php $__env->startSection('content'); ?>
<!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbss">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2><i class="icofont-bank-alt" style="font-size:25px;"></i> Tableau de bord</h2>
          <ol>
            <li><?php if(session('user')->roles == "Admin"): ?> 
            <a href="<?php echo e(route('tableau_de_bord')); ?>"><i class="icofont-bank-alt" style="font-size:25px;"></i> Tableau de bord</a>
		<?php elseif(session('user')->roles == "Client"): ?> 
		    <a href="<?php echo e(route('tableaudebord')); ?>"><i class="icofont-bank-alt" style="font-size:25px;"></i> Tableau de bord</a>
		<?php else: ?>
			<a href="<?php echo e(route('tb_de_bord')); ?>"><i class="icofont-bank-alt" style="font-size:25px;"></i> Tableau de bord</a>
		<?php endif; ?></li>
            <li>Tableau de bord</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->

    <!-- ======= Services Section ======= -->
   
    <!-- ======= Features Section ======= -->
     <section id="features" class="features">
      <div class="container" data-aos="fade-up">

        <div class="row">
		<?php
		$f = DB::table('inscription_operateur')->where('email', session('user')->email)->first()->id;
		$img = DB::table('catalogue_operateur')->where('inscription_id', $f)->get()->count();
		?>
		<div class="col-lg-12 col-md-4 mt-4 mt-md-0">
		<?php if($img > 0): ?>
			
		<?php else: ?>
			<div class="alert alert-danger" style="font-size: 15px; background-color: #fb5757; color: white">
                <i class="ti-na"></i> Veuillez ajouter 3 images au maximum de vos produits ou de votre entreprise 
            </div>
		<?php endif; ?>
		<?php if(session('status')): ?>
            <div class="alert alert-warning" style="font-size: 15px; background-color: #328039; color: white">
                <i class="fa fa-warning"></i> <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger" style="font-size: 15px; background-color: #fb5757; color: white">
                <i class="ti-na"></i> <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger" style="font-size: 15px; background-color: #fb5757; color: white" >
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li> <i class="ti-na"></i> <?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
		</div>
		<div class="col-lg-4 col-md-4 d-flex align-items-stretch">
            <div class="member" data-aos="fade-up">
              <div class="member-img">
				<?php
				$f = DB::table('inscription_operateur')->where('email', session('user')->email)->first()->fichier;
				$id = DB::table('inscription_operateur')->where('email', session('user')->email)->first()->id;
				?>
				<?php if($f ==""): ?>
                <img src="<?php echo e(asset('assets/img/team/team0.jpg')); ?>" class="img-fluid" alt="">
				<a type="button" href="#" class="btn btn-info" style="text-align:center;width:100%;color:#fff;">Mettre à jour mon image</a>
				<?php else: ?> 
				<img src="<?php echo e(asset("public/storage/".$f)); ?>" style="height:510;width:510;" class="img-fluid">
				<a type="button" href="#" class="btn btn-info" style="text-align:center;width:100%;color:#fff;">Mettre à jour mon image</a>
				<?php endif; ?>
              </div>
              <div class="member-info">
              </div>
            </div>
          </div>
          <div class="col-lg-8 col-md-8">
            <div class="icon-box">
              <i class="ri-store-line" style="color: #ffbb2c;"></i>
              <h3><a href="">Nom : <?php echo e(DB::table('users')->where('id',session('user')->id)->first()->name); ?></a><br/><hr/>
              <a href="">Raison sociale : <?php echo e(DB::table('inscription_operateur')->where('email',session('user')->email)->first()->raison_sociale); ?></a><br/><hr/>
              <a href="">Département : <?php echo e(DB::table('inscription_operateur')->where('email',session('user')->email)->first()->departement); ?></a><br/><hr/>
              <a href="">Province : <?php echo e(DB::table('inscription_operateur')->where('email',session('user')->email)->first()->province); ?></a><br/><hr/>
			  <a href="">Mon statut : <?php echo e(DB::table('users')->where('id',session('user')->id)->first()->roles); ?></a>
			  </h3>
            </div>
          </div>
		  </div>
		  
		  <div class="row">
		  <div class="col-lg-12">
		    <br>
		  </div>
		  <div class="col-lg-12">
		  <div class="icon-box">
		    <table border="1">
				<tr>
					<th style="text-align:center;width:350px;height:25px;">Chiffre d'affaire réalisé </th>
					<th style="text-align:center;width:350px;height:25px;">Commission sur le chiffre d'affaire </th>
					<th style="text-align:center;width:350px;height:25px;">Bonus de fin d’année  </th>
				</tr>
				<tr>
				<td style="text-align:center;width:350px;height:25px;">
					<?php
					$cd = \Illuminate\Support\Facades\DB::table('achat')->where('users_id',session('user')->id)->get()->sum('montant');
					$cd =  number_format($cd, 0, ' ', ' ');
					echo $cd."&nbsp;FCFA";
					?>
				</td>
				<td style="text-align:center;width:350px;height:25px;">
					<?php
					$cd = \Illuminate\Support\Facades\DB::table('achat')->where('users_id',session('user')->id)->get()->sum('montant');
					$comi= $cd*0.05;
					$comi =  number_format($comi, 0, ' ', ' ');
					echo $comi."&nbsp;FCFA";
					?>
				</td>
				<td>
				
				</td>
				</tr>
		    </table>
		  </div>
		  </div>
		  </div>
		  <br/>
		  <br/>
		  <?php
			$i = DB::table('inscription_operateur')->where('email', session('user')->email)->first()->id;
			$ii = DB::table('catalogue_operateur')->where('inscription_id', $i)->get();
			?>
		  <div class="row">
		      <div class="icon-box">
		  <table border="1">
		      <tr>
					<th colspan="2" style="text-align:center;width:350px;height:25px;">Images de produits ajoutées</th>
				</tr>
				<tr>
				    <th style="text-align:center;width:350px;height:25px;">N°</th>
					<th style="text-align:center;width:350px;height:25px;">Fichier</th>
				</tr>
				<tbody>
				<?php $__currentLoopData = $ii; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $images): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
				<td style="text-align:center;width:350px;height:25px;"><?php echo e($loop->iteration); ?></td>
				<td style="text-align:center;width:350px;height:25px;"><a href="<?php echo e(url("public/storage/".$images->fichier)); ?>"><?php echo e($images->nom_fichier); ?></a></tr>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
			</table>
        </div>

      </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/c1302473c/public_html/dunamisdegabon.com/resources/views/tb_de_bord.blade.php ENDPATH**/ ?>