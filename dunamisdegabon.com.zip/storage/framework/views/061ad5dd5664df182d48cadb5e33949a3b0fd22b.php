<?php $__env->startComponent('mail::message'); ?>
# Bonjour M./Mme <?php echo e($nom_rep); ?>

 
Votre inscription a été validée sur  notre plateforme et un compte espace opérateur vous a été généré. Vous pouvez accéder à votre compte avec les identifiants
suivants :<br>
<b>-Login :</b>  <?php echo e($password); ?><br>
<b>-Mot de passe :</b> <?php echo e($email); ?><br>

Merci de choisir être des nôtres ! Bonne continuation.,<br>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\projets\SiteWeb\resources\views/emails/messages/operateur.blade.php ENDPATH**/ ?>