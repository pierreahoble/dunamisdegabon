<?php $__env->startSection('title','Liste des demandes '); ?>
<?php $__env->startSection('content'); ?>
<!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbss">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2><i class="icofont-folder-open"></i> Liste des demandes</h2>
          <ol>
            <li>
			<?php if(session('user')->roles == "Admin"): ?> 
            <a href="<?php echo e(route('tableau_de_bord')); ?>"><i class="icofont-home"></i> Tableau de bord</a>
		<?php elseif(session('user')->roles == "Client"): ?> 
		    <a href="<?php echo e(route('tableaudebord')); ?>"><i class="icofont-home"></i> Tableau de bord</a>
		<?php else: ?>
			<a href="<?php echo e(route('tb_de_bord')); ?>"><i class="icofont-home"></i> Tableau de bord</a>
		<?php endif; ?>
			</li>
            <li>Liste des demandes</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->
	     <section id="features" class="features">
      <div class="container" data-aos="fade-up">

        <div class="row">
	<?php if(session('status')): ?>
            <div class="alert alert-warning" style="font-size: 15px; background-color: #328039; color: white">
                <i class="fa fa-warning"></i> <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger" style="font-size: 15px; background-color: #fb5757; color: white">
                <i class="ti-na"></i> <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger" style="font-size: 15px; background-color: #fb5757; color: white" >
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li> <i class="ti-na"></i> <?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
	<div class="col-lg-12 card">
	        <br>
			<h2 align="center">
             Liste des demandes
            </h2>
			 <br>
            <div class="table-responsive table-hover container">
				<table class="table">
				    <thead>
						<tr>
							<th width="220px">N°</th>
							<th width="220px">Nom & Prénoms</th>
							<th width="300px">Email</th>
							<th width="300px">Adresse</th>
							<th width="300px">Statut</th>
							<th width="300px">Téléphone</th>
							<th width="300px">Projet</th>
							<th width="300px">Fichier</th>
						</tr>
					</thead>
					<tbody>
					<?php $__currentLoopData = $projet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projets): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
					<td><?php echo e($loop->iteration); ?></td>
					<td><?php echo e($projets->nom_rep); ?></td>
					<td><?php echo e($projets->email); ?></td>
					<td><?php echo e($projets->adresse); ?></td>
					<td><?php echo e($projets->profil); ?> -
					<?php if($projets->raison_sociale != ""): ?>
					<?php echo e($projets->raison_sociale); ?>

					<?php endif; ?>
					</td>
					<td><?php echo e($projets->telephone); ?></td>
					<td>
					<?php if($projets->projet != ""): ?>
					<?php echo e(DB::table('projet')->where('id', $projets->projet)->first()->libelle); ?>

					<?php endif; ?>
					</td>
					<td><a href="<?php echo e(route('downloadDoc', ['pathFile' => explode('/', $projets->fichier)[1]])); ?>" >
                                    Télécharger document
                    </a></td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>	
            </div>
			<div class="blog-pagination">
              <?php echo e($projet->links()); ?>

            </div>
	</div>
	      </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/c1302473c/public_html/dunamisdegabon.com/resources/views/liste_des_demandes.blade.php ENDPATH**/ ?>