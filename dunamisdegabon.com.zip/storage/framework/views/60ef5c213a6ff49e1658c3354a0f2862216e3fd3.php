<?php $__env->startSection('title','Liste des demandes à traiter'); ?>
<?php $__env->startSection('content'); ?>
<!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbss">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2><i class="icofont-folder-open"></i> Liste des demandes à traiter</h2>
          <ol>
            <li>
			<?php if(session('user')->roles == "Admin"): ?> 
            <a href="<?php echo e(route('tableau_de_bord')); ?>"><i class="icofont-home"></i> Tableau de bord</a>
		<?php elseif(session('user')->roles == "Client"): ?> 
		    <a href="<?php echo e(route('tableaudebord')); ?>"><i class="icofont-home"></i> Tableau de bord</a>
		<?php else: ?>
			<a href="<?php echo e(route('tb_de_bord')); ?>"><i class="icofont-home"></i> Tableau de bord</a>
		<?php endif; ?>
			</li>
            <li>Liste des demandes à traiter</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->
	     <section id="features" class="features">
      <div class="container" data-aos="fade-up">

        <div class="row">
	
	<div class="col-lg-12 card">
	<?php if(session('status')): ?>
            <div class="alert alert-warning" style="font-size: 15px; background-color: #328039; color: white">
                <i class="fa fa-warning"></i> <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger" style="font-size: 15px; background-color: #fb5757; color: white">
                <i class="ti-na"></i> <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger" style="font-size: 15px; background-color: #fb5757; color: white" >
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li> <i class="ti-na"></i> <?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
	        <br>
			<h2 align="center">
             Liste des demandes à traiter
            </h2>
			 <br>
            <div class="table-responsive table-hover container">
				<table border="1" style="width:1300px;">
				    <thead>
						<tr>
							<th width="220px">N°</th>
							<th width="220px">Nom & Prénoms</th>
							<th width="300px">Email</th>
							<th width="300px">Adresse</th>
							<th width="300px">Statut</th>
							<th width="300px">Téléphone</th>
							<th width="300px">Projet</th>
							<th width="300px">Etat</th>
							<th style="width:400px;">Actions</th>
						</tr>
					</thead>
					<tbody>
					<?php $__currentLoopData = $projet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projets): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($projets->etat2 == 0): ?>
                            <?php
                                $reponses = [
                                    'badge' => 'primary',
                                    'etat' => 'Non traitée',
                               ];
                            ?>
						<?php elseif($projets->etat2 == 1): ?>
							<?php
                                $reponses = [
                                    'badge' => 'warning',
                                    'etat' => 'En traitement',
                               ];
                            ?>
							<?php elseif($projets->etat2 == 2): ?>
							<?php
                                $reponses = [
                                    'badge' => 'danger',
                                    'etat' => 'Fermée',
                               ];
                            ?>
					    <?php else: ?>
							<?php
                        $reponses = [
                            'badge' => 'success',
                            'etat' => 'Validée et clôturée',
							];

                    ?>
                    <?php endif; ?>
					<tr>
					<td><?php echo e($loop->iteration); ?></td>
					<td><?php echo e($projets->nom_rep); ?></td>
					<td><?php echo e($projets->email); ?></td>
					<td><?php echo e($projets->adresse); ?></td>
					<td><?php echo e($projets->profil); ?> -
					<?php if($projets->raison_sociale != ""): ?>
					<?php echo e($projets->raison_sociale); ?>

					<?php endif; ?>
					</td>
					<td><?php echo e($projets->telephone); ?></td>
					<td>
					<?php if($projets->projet != ""): ?>
					<?php echo e(DB::table('projet')->where('id', $projets->projet)->first()->libelle); ?>

					<?php else: ?>
					<?php echo e($projets->autre); ?>

					<?php endif; ?>
					</td>
					<td style="text-align:center;">
						<?php if($reponses['etat'] == "Non traitée"): ?>
                                <span class="badge badge-primary"> Non traitée </span>
                        <?php elseif($reponses['etat'] == "En traitement"): ?>
                                <span class="badge badge-warning"> En traitement </span>
                        <?php else: ?>
                                <span class="badge badge-<?php echo e($reponses['badge']); ?>"> <?php echo e($reponses['etat']); ?> </span>
                        <?php endif; ?>
					</td>
					<td>
					<a target="_blank" href="<?php echo e(route('fiche-demande-projet', ['id' =>$projets->id])); ?>" style="color:blue;height:25px;width:25px;">
                                    <i class="icofont-eye" style="height:25px;width:25px;"></i>
                    </a>
					<a target="_blank" href="<?php echo e(url("storage/".$projets->fichier)); ?>" style="color:brown;">
                                    <i class="icofont-download"></i>
                    </a>
					<?php if($projets->etat2 == 0): ?>
					<a class="data-traiter" data-id="<?php echo e($projets->id); ?>" href="#" style="color:yellow;">
                            <i class="icofont-close-squared-alt"></i>
                    </a>
					<?php endif; ?>
					<?php if($projets->etat2 == 0 || $projets->etat2 == 1): ?>
					<a class="data-valider" data-id="<?php echo e($projets->id); ?>" href="#" style="color:green;">
                                    <i class="icofont-checked"></i>
                    </a>
					<a class="data-fermer" data-id="<?php echo e($projets->id); ?>" href="#" style="color:red;">
                                    <i class="icofont-close-squared-alt"></i>
                    </a>
					<?php endif; ?>
					</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>	
            </div>
			<div class="blog-pagination" style="margin-top:15px;">
              <?php echo e($projet->links()); ?>

            </div>
	</div>
	      </div>
    </section>
	<div class="modal fade bd-example-modal-sm" id="Validermodal">
			<div class="modal-dialog modal-sm">
				<div class="modal-content">
					<div class="modal-body">
						<p>Etes-vous sûr de vouloir clôturer ce dossier ?</p>
					</div>
					<div class="modal-footer" style="background-color:#ffffff" id="valider">
	
					</div>
				</div>
			</div>
	</div>
	<div class="modal fade bd-example-modal-sm" id="Fermermodal">
			<div class="modal-dialog modal-sm">
				<div class="modal-content">
					<div class="modal-body">
						<p>Etes-vous sûr de vouloir fermer ce dossier ?</p>
					</div>
					<div class="modal-footer" style="background-color:#ffffff" id="fermer">
	
					</div>
				</div>
			</div>
	</div>
	<div class="modal fade bd-example-modal-sm" id="Traitermodal">
			<div class="modal-dialog modal-sm">
				<div class="modal-content">
					<div class="modal-body">
						<p>Etes-vous sûr de vouloir mettre en traitement ce dossier ?</p>
					</div>
					<div class="modal-footer" style="background-color:#ffffff" id="traiter">
	
					</div>
				</div>
			</div>
	</div>
	<?php $__env->startPush('scripts'); ?>
    
    <script>

           

            $(".data-valider").on('click', function () {
                    var id=$(this).data('id');
                    $.get('Demandes/'+id, function (data) {
                    
                        var html = ` 
                        
                        <button type="button" class="btn btn-sm btn btn-primary" data-dismiss="modal">Non</button>
                            <form action="<?php echo e(route('ValiderdPost')); ?>" method="post" style="display: inline">
                                    <?php echo e(csrf_field()); ?>

                                            <input type="hidden" value="`+data.demandes.id+`" name="id" >
                            <button type="submit" class="btn btn-sm btn btn-danger">Oui</button>

                        </form>`
                        ;

                        $('#valider').html('').append(html);

                    })
                    $('#Validermodal').modal();
                });

    
    
    </script>
	<script>
            $(".data-fermer").on('click', function () {
                    var id=$(this).data('id');
                    $.get('Demandes/'+id, function (data) {
                    
                        var html = ` 
                        
                        <button type="button" class="btn btn-sm btn btn-primary" data-dismiss="modal">Non</button>
                            <form action="<?php echo e(route('FermerdPost')); ?>" method="post" style="display: inline">
                                    <?php echo e(csrf_field()); ?>

                                            <input type="hidden" value="`+data.demandes.id+`" name="id" >
                            <button type="submit" class="btn btn-sm btn btn-danger">Oui</button>

                        </form>`
                        ;

                        $('#fermer').html('').append(html);

                    })
                    $('#Fermermodal').modal();
                });
    </script>
	<script>
            $(".data-traiter").on('click', function () {
                    var id=$(this).data('id');
                    $.get('Demandes/'+id, function (data) {
                    
                        var html = ` 
                        
                        <button type="button" class="btn btn-sm btn btn-primary" data-dismiss="modal">Non</button>
                            <form action="<?php echo e(route('TraiterdPost')); ?>" method="post" style="display: inline">
                                    <?php echo e(csrf_field()); ?>

                                            <input type="hidden" value="`+data.demandes.id+`" name="id" >
                            <button type="submit" class="btn btn-sm btn btn-danger">Oui</button>

                        </form>`
                        ;

                        $('#traiter').html('').append(html);

                    })
                    $('#Traitermodal').modal();
                });
    </script>
	

      
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projets\dunamisdegabon.com\resources\views/liste_des_demandes_a_traiter.blade.php ENDPATH**/ ?>