<?php $__env->startComponent('mail::message'); ?>
# Hey Admin

- <?php echo e($nom); ?>

- <?php echo e($email); ?>

- <?php echo e($sujet); ?>

- <?php echo e($msg); ?>


Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home/c1302473c/public_html/dunamisdegabon.com/resources/views/emails/messages/created.blade.php ENDPATH**/ ?>