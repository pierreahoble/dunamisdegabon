<?php $__env->startSection('title', 'Ajouter image produit'); ?>
<?php $__env->startSection('content'); ?>
 <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbss">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2><i class="icofont-file-jpg" style="font-size:25px;"></i> Ajouter image produit</h2>
          <ol>
            <li>
			<?php if(session('user')->roles == "Admin"): ?> 
            <a href="<?php echo e(route('tableau_de_bord')); ?>"><i class="icofont-bank-alt" style="font-size:25px;"></i> Tableau de bord</a>
		<?php elseif(session('user')->roles == "Client"): ?> 
		    <a href="<?php echo e(route('tableaudebord')); ?>"><i class="icofont-bank-alt" style="font-size:25px;"></i> Tableau de bord</a>
		<?php elseif(session('user')->roles == "Consultant"): ?> 
		    <a href="<?php echo e(route('tableaudebordconsultant')); ?>"><i class="icofont-bank-alt" style="font-size:25px;"></i>Tableau de bord</a>
		<?php else: ?>
			<a href="<?php echo e(route('tb_de_bord')); ?>"><i class="icofont-bank-alt" style="font-size:25px;"></i> Tableau de bord</a>
		<?php endif; ?>
			</li>
            <li> Ajouter image produit</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->
    <section id="contact" class="contact">
      <div class="container">
        <div class="row mt-12" data-aos="fade-up">
          <div class="col-lg-12">
		  <?php if(session('status')): ?>
				<div class="alert alert-success" style="font-size: 15px; background-color: #328039; color: white">
					<i class="ti-check"></i> <?php echo e(session('status')); ?>

				</div>
			<?php endif; ?>

			<?php if(session('error')): ?>
				<div class="alert alert-danger" style="font-size: 15px;color: white">
					<i class="ti-na"></i> <?php echo e(session('error')); ?>

				</div>
			<?php endif; ?>
		    <form method="post" action="<?php echo e(route('ajoutcatalogue')); ?>" role="form" class="php-email-form" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

			<br/>
			<div class="form-row">
				<div class="col-md-5 form-group">
				<label class="label-control">Importer votre photo passeport<font color="red">*</font></label>
                  <input type="file" name="photo" class="file-upload-default" required>
                </div>
                </div>
              <div class="form-row">
				<div class="col-md-12 form-group">
				<button type="submit" class="btn btn-primary">
						<i class="icofont-tick-mark"></i> Enregistrer
				</button>
				</div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section><!-- End Contact Section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/c1302473c/public_html/dunamisdegabon.com/resources/views/ajouter-catalogue.blade.php ENDPATH**/ ?>