<div class="social-buttons">
    <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(urlencode($url)); ?>"
       target="_blank">
	    <i class="bx bxl-facebook"></i>
    </a>
	<a href="https://twitter.com/intent/tweet?url=<?php echo e(urlencode($url)); ?>"
       target="_blank">
        <i class="bx bxl-twitter"></i>
    </a>
	<a href="https://plus.google.com/share?url=<?php echo e(urlencode($url)); ?>"
       target="_blank">
       <i class="bx bxl-google-plus"></i>
    </a>
	<a href="https://wa.me/numberoftelefonodewhatsapp/?url=<?php echo e(urlencode($url)); ?>"
       target="_blank">
       <i class="bx bxl-whatsapp"></i>
    </a>
	
</div><?php /**PATH C:\projets\SiteWeb\resources\views/components/share.blade.php ENDPATH**/ ?>