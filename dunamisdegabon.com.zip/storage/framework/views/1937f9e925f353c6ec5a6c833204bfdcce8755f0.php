<?php $__env->startSection('title', 'Nouvel abonnement'); ?>
<?php $__env->startSection('content'); ?>
 <!-- ======= Breadcrumbs ======= -->
   <!-- End Breadcrumbs -->
    <section id="contact" class="contact">
      <div class="container">

        <div class="row mt-5 justify-content-center" data-aos="fade-up">
          <div class="col-lg-6">
		  <div style="background-color:#fff;padding:15px;">
		  <h3 align="center">Ajouter un nouvel abonnement</h3>
		  </div>
		  <?php if(session('status')): ?>
				<div class="alert alert-success" style="font-size: 15px; background-color: #328039; color: white">
					<i class="ti-check"></i> <?php echo e(session('status')); ?>

				</div>
			<?php endif; ?>

			<?php if(session('error')): ?>
				<div class="alert alert-danger" style="font-size: 15px;color: white">
					<i class="ti-na"></i> <?php echo e(session('error')); ?>

				</div>
			<?php endif; ?>
			
			<br/>
		    <form method="post" action="<?php echo e(route('abonnementPost')); ?>" role="form" class="php-email-form" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

			<br/>
              <div class="form-row">
			  
				<div class="col-md-12 form-group">
				<label class="label-control">Code du client</label>
                  <select class="form-control" name="compte_id" required>
						<option value="">Sélectionner le code client</option>
						<?php $__currentLoopData = $cli; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($clis->users_id); ?>">Code : <?php echo e(DB::table('users')->where('id', $clis->users_id)->first()->code_dinvitation); ?>/ <?php echo e($clis->nom); ?> <?php echo e($clis->prenoms); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
                </div>
				<div class="col-md-12 form-group">
				<label class="label-control">Durée</label>
                  <select class="form-control" name="duree" required>
						<option value="">Sélectionner une durée</option>
						<option value="1 an">1 an</option>
						<option value="2 ans">2 ans</option>
						<option value="3 ans">3 ans</option>
					</select>
                </div>
				<div class="col-md-6 form-group">
							<button type="reset" class="btn btn-danger" style="width:100%;">
                                    Annuler
                            </button>
							</div>
							<div class="col-md-6 form-group">
							<button type="submit" class="btn btn-primary" style="width:100%;">
                                    Enregistrer
                            </button>
							</div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section><!-- End Contact Section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projets\SiteWeb\resources\views/abonnement.blade.php ENDPATH**/ ?>