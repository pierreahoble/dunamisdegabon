<?php $__env->startSection('title','Espace consultant'); ?>
<?php $__env->startSection('content'); ?>
<!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbss">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Espace consultant</h2>
          <ol>
            <li><?php if(session('user')->roles == "Admin"): ?> 
            <a href="<?php echo e(route('tableau_de_bord')); ?>">Tableau de bord</a>
		<?php elseif(session('user')->roles == "Client"): ?> 
		    <a href="<?php echo e(route('tableaudebord')); ?>">Tableau de bord</a>
		<?php elseif(session('user')->roles == "Consultant"): ?> 
		    <a href="<?php echo e(route('tableaudebordconsultant')); ?>">Tableau de bord</a>
		<?php else: ?>
			<a href="<?php echo e(route('tb_de_bord')); ?>">Tableau de bord</a>
		<?php endif; ?></li>
            <li>Tableau de bord</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->

    <!-- ======= Services Section ======= -->
   
    <!-- ======= Features Section ======= -->
     <section id="features" class="features" style="font-size:17px;">
	 
      <div class="container" data-aos="fade-up">

        <div class="row">
		<div class="col-lg-12 col-md-12">
		<?php if(session('status')): ?>
				<div class="alert alert-success" style="font-size: 15px; background-color: #328039; color: white">
					<i class="ti-check"></i> <?php echo e(session('status')); ?>

				</div>
			<?php endif; ?>

			<?php if(session('error')): ?>
				<div class="alert alert-danger" style="font-size: 15px;color: white">
					<i class="ti-na"></i> <?php echo e(session('error')); ?>

				</div>
			<?php endif; ?>
			</div>
			<div class="col-lg-3 col-md-3 d-flex align-items-stretch">
            <div class="member" data-aos="fade-up">
              <div class="member-img">
				<?php
				$f = DB::table('inscription_consultant')->where('email', session('user')->email)->first()->fichier;
				$id = DB::table('inscription_consultant')->where('email', session('user')->email)->first()->id;
				$langue = DB::table('langue_consultant')->where('inscription_id', $id)->get()->count();
				$lango = DB::table('langue_consultant')->where('inscription_id', $id)->get();
				$comp = DB::table('competence_consultant')->where('inscription_id', $id)->get()->count();
				$trav = DB::table('travaux_consultant')->where('inscription_id', $id)->get()->count();
				$compt = DB::table('competence_consultant')->where('inscription_id', $id)->get();
				$travau = DB::table('travaux_consultant')->where('inscription_id', $id)->get();
				if ($f=="") {
					$photo = 0;
				} else {
					$photo = 20;
				}
				if ($langue>0) {
					$languec = 20;
				} else {
					$languec = 0;
				}
				if ($comp>0) {
					$compc = 20;
				} else {
					$compc = 0;
				}
				if ($trav>0) {
					$travx = 20;
				} else {
					$travx = 0;
				}
				$total = $photo + $languec + $travx + $compc + 20;
				?>
				<?php if($f ==""): ?>
                <img src="<?php echo e(asset('assets/img/team/team0.jpg')); ?>" class="img-fluid" alt="">
				<a type="button" href="<?php echo e(route('ajouter-photo')); ?>" class="btn btn-info" style="text-align:center;width:100%;color:#fff;">Ajouter une photo de profil</a>
				<?php else: ?> 
				<img src="<?php echo e(asset("public/storage/".$f)); ?>" style="height:510;width:510;" class="img-fluid">
				<a type="button" href="<?php echo e(route('ajouter-photo')); ?>" class="btn btn-info" style="text-align:center;width:100%;color:#fff;">Modifier photo de profil</a>
				<?php endif; ?>
              </div>
              <div class="member-info">
              </div>
            </div>
          </div>
		  <div class="col-lg-9 col-md-12 mt-4 mt-md-0">
            <div class="icon-box">
              <h3><a href="">
			  Nom & Prénoms : <?php echo e(DB::table('compte')->where('users_id',session('user')->id)->first()->nom); ?> <?php echo e(DB::table('compte')->where('users_id',session('user')->id)->first()->prenoms); ?><br/><hr/>
			  Profil : <?php echo e(DB::table('users')->where('id',session('user')->id)->first()->roles); ?><br/><hr/>
			  Date de naissance : <?php echo e(DB::table('inscription_consultant')->where('email',session('user')->email)->first()->datenais); ?><br/><hr/>
			  Nationalité : <?php echo e(DB::table('inscription_consultant')->where('email',session('user')->email)->first()->nationalite); ?><br/><hr/>
			  Téléphone : <?php echo e(DB::table('inscription_consultant')->where('email',session('user')->email)->first()->telephone); ?><br/><hr/>
			  Ville : <?php echo e(DB::table('inscription_consultant')->where('email',session('user')->email)->first()->ville); ?><br/><hr/>
			  Email : <?php echo e(DB::table('inscription_consultant')->where('email',session('user')->email)->first()->email); ?><br/><hr/>
			  </a></h3>
            </div>
          </div>
          <div class="col-lg-12 col-md-9 mt-4 mt-md-0 skills-content">
            <div class="icon-box">
              <i class="ri-bar-chart-box-line" style="color: #5578ff;"></i>
              <h3><a href=""  style="color:red;">Votre profil est complèté à  : <?php echo e($total); ?> %</a></h3>
			 
			<br/>
			<br/>
            </div>
          </div>
		  <div class="col-lg-12 col-md-12 mt-4 mt-md-0">
			<div class="icon-box">
              <i class="ri-bar-chart-box-line" style="color: #5578ff;"></i>
              <h3><a href="">Travaux illustrant le mieux mes compétences</a></h3>
			 
			<br/>
			<br/>
			
            </div>
			<div class="icon-box">
			<table border="1">
			<tr>
				<th style="width:200px;text-align:center" colspan="10">Travaux réalisés(Expérience)</th>
			</tr>
			<tr>
				<th style="width:200px;text-align:center">Client</th>
				<th style="width:200px;text-align:center">Profil</th>
				<th style="width:200px;text-align:center">Activité principale</th>
				<th style="width:200px;text-align:center">Début</th>
				<th style="width:200px;text-align:center">Année</th>
				<th style="width:200px;text-align:center">Fin</th>
				<th style="width:200px;text-align:center">Année</th>
				<th style="width:200px;text-align:center">Lieu</th>
				<th style="width:200px;text-align:center">Missions menées</th>
				<th style="width:200px;text-align:center">Actions</th>
			</tr>
			<tbody>
			<?php $__currentLoopData = $travau; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $travaux): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td style="width:200px;text-align:center"><?php echo e($travaux->client); ?></td>
				<td style="width:200px;text-align:center"><?php echo e($travaux->profil); ?></td>
				<td style="width:200px;text-align:center"><?php echo e($travaux->activite_principale); ?></td>
				<td style="width:200px;text-align:center"><?php echo e($travaux->moisdebut); ?></td>
				<td style="width:200px;text-align:center"><?php echo e($travaux->anneedebut); ?></td>
				<td style="width:200px;text-align:center"><?php echo e($travaux->moisfin); ?></td>
				<td style="width:200px;text-align:center"><?php echo e($travaux->anneefin); ?></td>
				<td style="width:200px;text-align:center"><?php echo e($travaux->lieu); ?></td>
				<td style="width:200px;text-align:center"><?php echo e($travaux->mission); ?></td>
				<td style="width:200px;text-align:center">
				<a href="<?php echo e(route('travauxsupprimer',['id'=>$travaux->id])); ?>"><i class="icofont-close-squared-alt" style="color:red;font-size:15px;"></i></a>
				</td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<tr>
			<td colspan="10" style="text-align:center;color:blue;"><a href="<?php echo e(route('ajouter-travaux')); ?>">Ajouter</a></td>
			</tr>
			</tbody>
			</table>
		  </div>
		  </div>
		  <div class="col-lg-12 col-md-12 mt-4 mt-md-0">
			<div class="icon-box">
              <i class="ri-bar-chart-box-line" style="color: #5578ff;"></i>
              <h3><a href="">Mes compétences</a></h3>
			 
			<br/>
			<br/>
			
            </div>
			<div class="icon-box">
			<table border="1">
			<tr>
				<th style="width:200px;text-align:center" colspan="5">Mes compétences</th>
			</tr>
			<tr>
				<th style="width:200px;text-align:center">Compétence</th>
				<th style="width:200px;text-align:center">Niveau</th>
				<th style="width:200px;text-align:center">Diplôme</th>
				<th style="width:200px;text-align:center">Fichier</th>
				<th style="width:200px;text-align:center">Actions</th>
			</tr>
			<tbody>
			<?php $__currentLoopData = $compt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td style="width:200px;text-align:center"><?php echo e($compts->libelle); ?></td>
				<td style="width:200px;text-align:center"><?php echo e($compts->niveau); ?></td>
				<td style="width:200px;text-align:center"><?php echo e($compts->diplome); ?></td>
				<td style="width:200px;text-align:center"></td>
				<td style="width:200px;text-align:center">
				<a href="<?php echo e(route('competencesupPost',['id'=>$compts->id])); ?>"><i class="icofont-close-squared-alt" style="color:red;font-size:15px;"></i></a>
				</td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<tr>
			<td colspan="5" style="text-align:center;color:blue;"><a href="<?php echo e(route('ajouter-competence')); ?>">
			<i class="icofont-plus" style="font-size:15px;"></i>Ajouter</a></td>
			</tr>
			</tbody>
			</table>
		  </div>
		  </div>
		  <div class="col-lg-12 col-md-12 mt-4 mt-md-0">
			<div class="icon-box">
              <i class="ri-bar-chart-box-line" style="color: #5578ff;"></i>
              <h3><a href="">Langues</a></h3>
			 
			<br/>
			<br/>
			
            </div>
			<div class="icon-box">
			<table border="1">
			<tr>
				<th style="width:200px;text-align:center" colspan="3">Mes langues</th>
			</tr>
			<tr>
				<th style="width:200px;text-align:center">Langue</th>
				<th style="width:200px;text-align:center">Niveau</th>
				<th style="width:200px;text-align:center">Actions</th>
			</tr>
			<tbody>
			<?php $__currentLoopData = $lango; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $langos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td style="width:200px;text-align:center"><?php echo e($langos->libelle); ?></td>
				<td style="width:200px;text-align:center"><?php echo e($langos->niveau); ?></td>
				<td style="width:200px;text-align:center">
				<a href="<?php echo e(route('languesupPost',['id'=>$langos->id])); ?>"><i class="icofont-close-squared-alt" style="color:red;font-size:15px;"></i></a>
				</td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<tr>
			<td colspan="3" style="text-align:center;color:blue;"><a href="<?php echo e(route('ajouter-langue')); ?>">
			<i class="icofont-plus" style="font-size:15px;"></i>Ajouter</a></td>
			</tr>
			</tbody>
			</table>
		  </div>
		  </div>
		  
		  </div>
		  
		  <div class="row">
		  <div class="col-lg-12">
		    <br>
		  </div>
		  </div>
        </div>
      </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/c1302473c/public_html/dunamisdegabon.com/resources/views/tableaudebordconsultant.blade.php ENDPATH**/ ?>