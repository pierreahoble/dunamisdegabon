<?php $__env->startSection('title','Banque de projet '); ?>
<?php $__env->startSection('description','Banque de projet '); ?>
<?php $__env->startSection('content'); ?>
    <!-- ======= About Us Section ======= -->
     <!-- ======= Our Team Section ======= -->
    <section id="team" class="team section-bg">
      <div class="container">

        <div class="section-title" data-aos="fade-up">
          <h2>Banque de <strong>projets</strong></h2>
          <p>Nous avons déjà à notre disposition plus de 300 idées de projets de création d'entreprise. Vous ne trouvez pas votre projet? Ecrivez-nous 
		  <a type="button" class="btn btn-success" href="https://api.whatsapp.com/send?phone=00241077816737&text=Bonjour,%20j'ai%20une%20idée%20de%20projet%20que%20j'aimerais%20vous%20soumettre" target="_blank"> <i class="icofont-whatsapp"></i> Par whatsapp</a>
		  ou soummettre votre projet avec détails en remplissant le formulaire <a type="button" class="btn btn-warning" href="<?php echo e(route('demande-de-projet')); ?>" style="color:#fff"><i class="icofont-aim"></i> Soumttre mon projet</a></p>
        </div>
		<div class="row">
		<div class="col-lg-12">
		  <?php if(session('status')): ?>
				<div class="alert alert-success" style="font-size: 15px; background-color: #328039; color: white">
					<i class="ti-check"></i> <?php echo e(session('status')); ?>

				</div>
			<?php endif; ?>

			<?php if(session('error')): ?>
				<div class="alert alert-danger" style="font-size: 15px;color: white">
					<i class="ti-na"></i> <?php echo e(session('error')); ?>

				</div>
			<?php endif; ?>
		    <form method="post" role="form" class="php-email-form">
            <?php echo e(csrf_field()); ?>

			<br/>
			<div class="form-row">
				<div class="col-md-6 form-group">
				<label class="label-control">Sélectionner une catégorie<font color="red">*</font></label>
                  <select id="niveau" type="text" class="form-control" name="langue" id="selecttype" required>
					<option value="0">Veuillez sélectionner</option>
					<?php $__currentLoopData = $typepro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $typepro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($typepro->id); ?>"><?php echo e($typepro->libelle); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				  </select>
                </div>
                </div>
            </form>
          </div>
		</div>
        <div class="row" id="projetnonselectionner">
			<?php $__currentLoopData = $projet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projets): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
            <div class="member" data-aos="fade-up" >
              <div class="member-img">
			  <img src="<?php echo e(asset("storage/".$projets->fichier)); ?>" alt="" class="img-fluid"/>
                <div class="social">
                  <a type="button" class="btn btn-success" href="https://api.whatsapp.com/send?phone=00241077816737&text=Bonjour,%20je suis%20interessé%20par%20le%20projet : <?php echo e($projets->libelle); ?>" target="_blank" style="color:#fff;"> <i class="icofont-whatsapp"></i> En savoir plus</a>
                </div>
              </div>
              <div class="member-info">
                <h4><?php echo e($projets->typepro); ?></h4>
                <span><?php echo e($projets->libelle); ?></span>
              </div>
            </div>
          </div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			 </div>
	  <div class="row" id="projetselectionner">
		 <input type="hidden" value="<?php echo e($pro); ?>" id="tousprojets">
		   <div class="col-lg-3 col-md-6 d-flex align-items-stretch" id="selectpro">
         
              <div class="member" data-aos="fade-up" >
              <div class="member-img">
			  <img src=""/>
                <div class="social">
                  <a type="button" class="btn btn-success" href="https://api.whatsapp.com/send?phone=00241077816737&text=Bonjour,%20je suis%20interessé%20par%20le%20projet " target="_blank" style="color:#fff;"> <i class="icofont-whatsapp"></i> En savoir plus</a>
                </div>
              </div>
              <div class="member-info">
                <h4></h4>
                <span></span>
              </div>
            </div>
          
		    </div>
       
		</div>
		<div class="blog-pagination">
              <?php echo e($projet->links()); ?>

        </div>
		
		
		
		
      </div>
    </section><!-- End Our Team Section -->
    <section class="full-row bg-default">
		<div class="container">
				<div class="get-tch full-row">
				<div class="row">
					<div class="col-md-8 col-sm-8">
						<h3 class="color-white no-margin">Vous êtes interessés par l'un de nos projets?</h3>
					</div>
					<div class="col-md-4 col-sm-4 box-right-middle">
						<a class="btn btn-large" href="<?php echo e(route('choisir-projet')); ?>">Soumettre votre projet</a>
					</div>
				</div>
			</div>
		</div>
	</section>
	
	<?php $__env->startPush('scripts'); ?>
	
	<script>
	
	$(document).ready(function(){
		
		 $('#projetselectionner').hide();
									
								$('select[name="langue"]').change(function(){
									var valeur = $(this).val();
									
										if (valeur == '0'){
											$('#projetnonselectionner').show();
											$('#projetselectionner').hide();
										} else {
											$('#projetnonselectionner').hide();
											$('#projetselectionner').show();
										}
									
								});
								
								
		
	});
	
	
	</script>
	
	<script>
						 $('#selecttype').change(function(h){
							 
							
					
						var typeprojet= $('#tousprojets').val();
						var typeprojetselectionner=$('#selecttype').val();
						typeprojet=JSON.parse(typeprojet);
						typeprojet=typeprojet.filter(function(x){
							return x.idtypepro==typeprojetselectionner;
						});
						 
						 var option = '  <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
						 <div class="member" data-aos="fade-up" >
              <div class="member-img">
			  <img src=""/>
                <div class="social">
                  <a type="button" class="btn btn-success" href="https://api.whatsapp.com/send?phone=00241077816737&text=Bonjour,%20je suis%20interessé%20par%20le%20projet " target="_blank" style="color:#fff;"> <i class="icofont-whatsapp"></i> En savoir plus</a>
                </div>
              </div>
              <div class="member-info">
                <h4></h4>
                <span></span>
              </div>
            </div>
			</div>
			';
						 for(var i=0; i<typeprojet.length; i++){
							option+=`
					  <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
						<div class="member" data-aos="fade-up" >
						  <div class="member-img">
						  <img value="`+typeprojet[i].id+`" src="<?php echo e(asset('storage/'.`+typeprojet[i].fichier+`)); ?>"  class='img-fluid'/>
							<div class="social">
							  <a type="button" class="btn btn-success" href="https://api.whatsapp.com/send?phone=00241077816737&text=Bonjour,%20je suis%20interessé%20par%20le%20projet " target="_blank" style="color:#fff;"> <i class="icofont-whatsapp"></i> En savoir plus</a>
							</div>
						  </div>
						  <div class="member-info">
							<h4 value="`+typeprojet[i].id+`">`+typeprojet[i].typepro+`</h4>
							<span value="`+typeprojet[i].id+`">`+typeprojet[i].libelle+`</span>
						  </div>
						</div>
						</div>
					  `;

						}
						$('#selectpro').html(option);
					
					}) 

					</script>
					<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projets\dunamisdegabon.com\resources\views/banque-de-projet.blade.php ENDPATH**/ ?>