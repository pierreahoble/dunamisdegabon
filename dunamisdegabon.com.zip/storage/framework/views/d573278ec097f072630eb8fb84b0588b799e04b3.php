<?php $__env->startSection('title','Tableau de bord'); ?>
<?php $__env->startSection('content'); ?>
<!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Tableau de bord</h2>
          <ol>
            <li><?php if(session('user')->roles == "Admin"): ?> 
            <a href="<?php echo e(route('tableau_de_bord')); ?>">Tableau de bord</a>
		<?php elseif(session('user')->roles == "Client"): ?> 
		    <a href="<?php echo e(route('tableaudebord')); ?>">Tableau de bord</a>
		<?php else: ?>
			<a href="<?php echo e(route('tb_de_bord')); ?>">Tableau de bord</a>
		<?php endif; ?></li>
            <li>Tableau de bord</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->

    <!-- ======= Services Section ======= -->
   
    <!-- ======= Features Section ======= -->
     <section id="features" class="features">
      <div class="container" data-aos="fade-up">

        <div class="row">
		<div class="col-lg-12 col-md-4 mt-4 mt-md-0">
		<?php if(session('status')): ?>
            <div class="alert alert-warning" style="font-size: 15px; background-color: #328039; color: white">
                <i class="fa fa-warning"></i> <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger" style="font-size: 15px; background-color: #fb5757; color: white">
                <i class="ti-na"></i> <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger" style="font-size: 15px; background-color: #fb5757; color: white" >
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li> <i class="ti-na"></i> <?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
		</div>
          <div class="col-lg-4 col-md-4">
            <div class="icon-box">
              <i class="ri-store-line" style="color: #ffbb2c;"></i>
              <h3><a href="">Nom : <?php echo e(DB::table('users')->where('id',session('user')->id)->first()->name); ?></a></h3>
            </div>
          </div>
          <div class="col-lg-4 col-md-4 mt-4 mt-md-0">
            <div class="icon-box">
              <i class="ri-bar-chart-box-line" style="color: #5578ff;"></i>
              <h3><a href="">Mon statut : <?php echo e(DB::table('users')->where('id',session('user')->id)->first()->roles); ?></a></h3>
            </div>
          </div>
          <div class="col-lg-4 col-md-4 mt-4 mt-md-0">
            <div class="icon-box">
              <i class="ri-calendar-todo-line" style="color: #e80368;"></i>
              <h3><a href="">N° Matricule : <?php echo e(DB::table('users')->where('id',session('user')->id)->first()->code_dinvitation); ?></a></h3>
            </div>
          </div>
		  </div>
		  
		  <div class="row">
		  <div class="col-lg-12">
		    <br>
		  </div>
		  </div>
		  <div class="row">
          <div class="col-lg-6 col-md-6 mt-4 mt-md-0">
            <div class="icon-box">
              <i class="ri-gradienter-line" style="color: #ffa76e;"></i>
              <h3><a href="">Chiffre d'affaire réalisé : 
			  <?php
				$cd = \Illuminate\Support\Facades\DB::table('achat')->where('users_id',session('user')->id)->get()->sum('montant');
				$cd =  number_format($cd, 0, ' ', ' ');
				echo $cd."&nbsp;FCFA";
				?>
			  </a>&nbsp;</h3>
            </div>
          </div>
          <div class="col-lg-6 col-md-6 mt-4 mt-md-0">
            <div class="icon-box">
              <i class="ri-file-list-3-line" style="color: #11dbcf;"></i>
              <h3><a href="">Commission sur le chiffre d'affaire: 
				<?php
				$cd = \Illuminate\Support\Facades\DB::table('achat')->where('users_id',session('user')->id)->get()->sum('montant');
				$comi= $cd*0.05;
				$comi =  number_format($comi, 0, ' ', ' ');
				echo $comi."&nbsp;FCFA";
				?>

			  </a></h3>
            </div>
          </div>
		  </div>
		  <div class="row">
          <div class="col-lg-6 col-md-4 mt-4">
            <div class="icon-box">
              <i class="ri-price-tag-2-line" style="color: #4233ff;"></i>
              <h3><a href="<?php echo e(route('liste_des_achats')); ?>">Voir la liste des achats</a></h3>
            </div>
          </div>
          <div class="col-lg-6 col-md-4 mt-4">
            <div class="icon-box">
              <i class="ri-anchor-line" style="color: #b2904f;"></i>
              <h3><a href="">Bonus de fin d’année :  </a></h3>
            </div>
          </div>
		  </div>
          
        </div>

      </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projets\SiteWeb\resources\views/tb_de_bord.blade.php ENDPATH**/ ?>