<?php $__env->startSection('title', 'Succès inscription'); ?>
<?php $__env->startSection('content'); ?>
 <!-- ======= Breadcrumbs ======= -->
   <!-- End Breadcrumbs --><br/><br/><br/><br/>
    <section id="contact" class="contact" style="background-color:#fff;">
      <div class="container">

        <div class="row mt-10 justify-content-center" data-aos="fade-up">
          <div class="section-header text-center" style="padding-top: 50px">
		  <?php if(session('status')): ?>
                        <div class="alert alert-success" style="font-size: 15px; background-color: #328039; color: white">
                            <i class="ti-check"></i> <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(session('error')): ?>
                        <div class="alert alert-danger" style="font-size: 15px; background-color: #fb5757; color: white">
                            <i class="ti-na"></i> <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger" style="font-size: 15px; background-color: #fb5757; color: white" >
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li> <i class="ti-na"></i> <?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
         
        </div>
		
		<div class="col-md-18">
		<br/>
		<div class="alert alert-success" style="font-size: 20px; color: white;background-color:green;text-align:center;">
		<br/><br/><br/>
                            <i class="ti-na"></i> Votre inscription s'est bien déroulé avec succès! <br/>Nous sommes heureux de vous compter parmi nous.<br/>
							Veuillez vous connecter à votre espace opérateur en cliquant sur le lien suivant <br/><br/>
							<a href="login" type="button" class="btn btn-danger" style="color:#fff">Connexion opérateur</a>
                        <br/><br/><br/><br/>
						</div>
        </div>
		</div>
      </div>
    </section><!-- End Contact Section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projets\dunamisdegabon.com\resources\views/succes.blade.php ENDPATH**/ ?>