<?php $__env->startSection('title', 'Choix du profil'); ?>
<?php $__env->startSection('content'); ?>
 <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Choix du profil</h2>
          <ol>
            <li><a href="<?php echo e(url('/choix-profil')); ?>">Accueil</a></li>
            <li>Choix du profil</li>
          </ol>
        </div>

      </div>
    </section>
	<!-- ======= About Us Section ======= -->
    <section id="about-us" class="about-us" style="background-color:#fff;">
      <div class="container" data-aos="fade-up">
		<div class="section-title">
          <h2>INSCRIPTION</strong></h2>
        </div>
        <div class="row content">
          <div class="col-lg-12 well pt-4 pt-lg-0" data-aos="fade-left">
			<p align="">Pour vous enregistrer, veuillez cliquer sur l'un des boutons ci-après ou télécharger le formulaire en format word, le 
			remplir et nous l'envoyer par mail sur info@dunamisdegabon.com.
			</p>
          </div>
		  
        </div>

      </div>
	 
    </section><!-- End About Us Section -->
    <section id="contact" class="contact">
      <div class="container">

        <div class="row justify-content-center" data-aos="fade-up">
          <div class="col-lg-12">
		  <?php if(session('status')): ?>
				<div class="alert alert-success" style="font-size: 15px; background-color: #328039; color: white">
					<i class="ti-check"></i> <?php echo e(session('status')); ?>

				</div>
			<?php endif; ?>

			<?php if(session('error')): ?>
				<div class="alert alert-danger" style="font-size: 15px;color: white">
					<i class="ti-na"></i> <?php echo e(session('error')); ?>

				</div>
			<?php endif; ?>
		        <div class="row">
				<div class="col-md-3 form-group">
				<a href="<?php echo e(route('inscription-consultant')); ?>" type="button" class="btn btn-danger" style="width:100%;height:300px;text-align:center;">
			<br><br><br><br><br>
						INSCRIPTION CONSULTANT
				</a>
				<p align="center"><br><a href="<?php echo e(asset('assets/doc/form_consultant.docx')); ?>">TÉLÉCHARGER FORMULAIRE CONSULTANT</a></p>
				</div>
				<div class="col-md-3 form-group">
				<a href="<?php echo e(route('inscription-partenaire')); ?>" type="button" class="btn btn-primary" style="width:100%;height:300px;text-align:center;">
			<br><br><br><br><br>
						INSCRIPTION PARTENAIRE
				</a>
				<p align="center"><br><a href="<?php echo e(asset('assets/doc/form_partenaire.docx')); ?>">TÉLÉCHARGER FORMULAIRE PARTENAIRE</a></p>
				</div>
				<div class="col-md-3 form-group">
				<a href="<?php echo e(route('inscription-operateur')); ?>" type="button" class="btn btn-warning" style="width:100%;height:300px;text-align:center;">
			<br><br><br><br><br>
						<font color="#fff">INSCRIPTION OPÉRATEUR ÉCONOMIQUE</font>
				</a>
				<p align="center"><br><a href="<?php echo e(asset('assets/doc/form_operateur.docx')); ?>">TÉLÉCHARGER FORMULAIRE OPÉRATEUR</a></p>
				</div>	
				<div class="col-md-3 form-group">
				<a href="<?php echo e(route('inscription')); ?>" type="button" class="btn btn-success" style="width:100%;height:300px;text-align:center;">
			<br><br><br><br><br>
						INSCRIPTION CLIENT
				</a>
				</div>
              </div>
          </div>
        </div>
      </div>
    </section><!-- End Contact Section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projets\SiteWeb\resources\views/sinscrire.blade.php ENDPATH**/ ?>