<?php $__env->startComponent('mail::message'); ?>
# Bonjour administrateur
 
Une demande de projet vient d'être enregistré. Veuillez vous connecter pour traiter la demande<br>

Merci.<br>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\projets\SiteWeb\resources\views/emails/messages/demande.blade.php ENDPATH**/ ?>