<?php $__env->startSection('title', 'Nos consultants'); ?>
<?php $__env->startSection('content'); ?>
 <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Nos consultants</h2>
          <ol>
            <li><a href="<?php echo e(url('/choix-profil')); ?>">Accueil</a></li>
            <li>Nos consultants</li>
          </ol>
        </div>

      </div>
    </section>
	<!-- ======= About Us Section ======= -->
    
     <!-- ======= Our Team Section ======= -->
    <section id="team" class="team section-bg">
      <div class="container">

        <div class="section-title" data-aos="fade-up">
          <h2>Nos <strong>consultants</strong></h2>
          <p>Liste complète de tous nos consultants</p>
        </div>

        <div class="row">
		<?php $__currentLoopData = $consultant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consultants): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
            <div class="member" data-aos="fade-up">
              <div class="member-img">
                <img src="<?php echo e(asset("public/storage/".$consultants->fichier)); ?>" class="img-fluid" alt="">
                <div class="social" style="font-size:11px;">
                  <?php echo e($consultants->email); ?>

                </div>
              </div>
              <div class="member-info">
                <h4 style="font-size:12px;"><a target="_blank" href="<?php echo e(route('profil', ['id'=>$consultants->id])); ?>"><?php echo e($consultants->nom); ?></a></h4>
                <span><?php echo e($consultants->competence); ?></span>
              </div>
            </div>
          </div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<div class="blog-pagination">
              <?php echo e($consultant->links()); ?>

            </div>
        </div>

      </div>
    </section><!-- End Our Team Section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/c1302473c/public_html/dunamisdegabon.com/resources/views/nos-consultants.blade.php ENDPATH**/ ?>