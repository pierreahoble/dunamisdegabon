<?php $__env->startSection('title', 'Succès inscription'); ?>
<?php $__env->startSection('content'); ?>
 <!-- ======= Breadcrumbs ======= -->
   <!-- End Breadcrumbs --><br/><br/><br/><br/>
    <section id="contact" class="contact">
      <div class="container">

        <div class="row mt-10 justify-content-center" data-aos="fade-up">
          <div class="section-header text-center" style="padding-top: 50px">
		  <?php if(session('status')): ?>
                        <div class="alert alert-success" style="font-size: 15px; background-color: #328039; color: white">
                            <i class="ti-check"></i> <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(session('error')): ?>
                        <div class="alert alert-danger" style="font-size: 15px; background-color: #fb5757; color: white">
                            <i class="ti-na"></i> <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger" style="font-size: 15px; background-color: #fb5757; color: white" >
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li> <i class="ti-na"></i> <?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
         
        </div>
		
		<div class="col-md-10" style="padding:20px;background-color:#dbdbdb;width:100%;height:400px;border:5px;">
		<br/><br/><br/><br/><br/><br/>
		<center><i class="fa fa-download"></i><a target="_blank" href="<?php echo e(route('fiche-d-inscription')); ?>" style="text-align:center;margin-top:50px;"> TÉLÉCHARGER UNE COPIE DE VOTRE FORMULAIRE</a></center>
        </div>
		</div>
      </div>
    </section><!-- End Contact Section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projets\SiteWeb\resources\views/succes.blade.php ENDPATH**/ ?>