<?php $__env->startSection('title', 'Publications'); ?>
<?php $__env->startSection('content'); ?>
 <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Plateforme e-commerce</h2>
          <ol>
            <li><a href="<?php echo e(url('/')); ?>">Accueil</a></li>
            <li>Plateforme e-commerce</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->
	
    <!-- ======= Blog Section ======= -->
    <section id="blog" class="blog" style="background-color:#fff;">
      <div class="container">

        <div class="row">

          <div class="col-lg-8 entries">
		  <div class="container" data-aos="fade-up">

        <div class="row content">
          <div class="col-lg-12 pt-4 pt-lg-0" data-aos="fade-left">
		  <h3 align="left" style="color:blue;">Plateforme de commerce en ligne (E-dunamis)</h3><br/>
            <p align="justify">
              Chez ….. Club, vous ne faites pas que simple achat de biens et services. En devenant client nn Club, nous vous donnons la
			possibilité, de disposer des revenus supplémentaires par vos simples achats.
			XXXX et les entreprises nationales se sont engagés dans une convention de partenariat pour amorcer ensemble un
			développement durable. La création du Réseau inaugure le redéploiement des actions marketing pour fidéliser les clients,
			booster le chiffre par l’effet de volume, auprès des entreprises du réseau. Ce programme de fidélité, permettra aux clients
			de bénéficier d'avantages exclusifs comme:
<br/>

            </p>
            <ul>
              <li style="text-align:justify;"><i class="ri-check-double-line"></i> x% de remise sur vos achats dans le réseau xx Club;</li>
              <li style="text-align:justify;"><i class="ri-check-double-line"></i> Un avantage intéressant pour bénéficier des meilleures conditions tarifaires pour vos achats dans les boutiques,
				supermarchés, acquisitions de matériels, vos séminaires, formations ou événements clients, location d’hôtels, frais de
				formation …</li>
              <li style="text-align:justify;"><i class="ri-check-double-line"></i> Accès à une plateforme d'achats vous permettant d'obtenir des réductions sur des services B to B (réservations d'hôtels, de
				voitures, etc...).</li>
              <li style="text-align:justify;"><i class="ri-check-double-line"></i> Cet avantage est particulièrement destiné aux clients chez nnn Club, avec des réductions allant jusqu'à x% pour certains
fournisseurs.</li>
              
             
            </ul>
			<p>
			  Vous êtes impatient de devenir un vrai nnnn et de profiter d'avantages uniques ? <a href="<?php echo e(url('/sinscrire')); ?>" style="color:red;">Inscrivez-vous sans plus tarder !</a>
              </p>
          </div>
        </div>
      </div>
	  <br/><br/>
	  <h3 align="left" style="color:blue;">Nos commerçants</h3><br/>
	  
			<?php $__currentLoopData = $pub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pubs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article class="entry" data-aos="fade-up">

              <div class="entry-img">
			  <img src="<?php echo e(asset("storage/".$pubs->images)); ?>" alt="" class="img-fluid"/>
               <!-- <img src="assets/img/blog-1.jpg" alt="" class="img-fluid">-->
              </div>

              <h2 class="entry-title">
                <a href="blog-single.html"><?php echo e($pubs->titre); ?></a>
              </h2>

              <div class="entry-meta">
                <ul>
                  <li class="d-flex align-items-center"><i class="icofont-user"></i> <a href="blog-single.html"><?php echo e(DB::table('users')->where('id',$pubs->users_id)->first()->name); ?></a></li>
                  <li class="d-flex align-items-center"><i class="icofont-wall-clock"></i> <a href="blog-single.html"><time datetime="2020-01-01"><?php echo e($pubs->date2); ?></time></a></li>
                </ul>
              </div>

              <div class="entry-content">
                <p>
                  <?php echo e($pubs->contenu); ?>

                </p>
                <div class="read-more">
                  <a href="<?php echo e(route('post', ['id'=>$pubs->id])); ?>">En savoir plus</a>
                </div>
              </div>

            </article><!-- End blog entry -->
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="blog-pagination">
              <?php echo e($pub->links()); ?>

            </div>

          </div><!-- End blog entries list -->

          <div class="col-lg-4">

            <div class="sidebar" data-aos="fade-left">

              <h3 class="sidebar-title">Menu second</h3>
              <!-- End sidebar search formn-->
				<ul>
				<li><a href="<?php echo e(route('bureau-d-etude')); ?>">Bureau d’études </a></li>
				<li><a href="<?php echo e(url('/incubateur-d-entreprise')); ?>">Incubateur d’entreprises </a></li>
				<li><a href="<?php echo e(route('boutique')); ?>">E-dunamis</a></li>
				</ul><!-- End sidebar search formn-->

              <h3 class="sidebar-title">Toutes les catégories</h3>
              <div class="sidebar-item categories">
                <ul>
				<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><a href="#"><?php echo e($categorie->libelle); ?> <span><?php echo e(DB::table('pub')->where('categorie_id',$categorie->id)->count()); ?></span></a></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

              </div><!-- End sidebar categories-->

              <h3 class="sidebar-title">Anciennement postées</h3>
              <div class="sidebar-item recent-posts">
				<?php $__currentLoopData = $pub2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pub3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="post-item clearfix">
                  <img src="<?php echo e(asset("storage/".$pub3->images)); ?>" alt="">
                  <h4><a href="blog-single.html"><?php echo e($pub3->titre); ?></a></h4>
                  <time datetime="2020-01-01"><?php echo e($pub3->date2); ?></time>
                </div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </div><!-- End sidebar recent posts-->

              <!-- End sidebar tags-->
				 <br/>
	 <p align="center"><button class="btn btn-warning"><a href="<?php echo e(route('inscription-operateur')); ?>" style="color:#fff;">Voulez-vous rejoindre la plateforme des commerçants? Inscrivez-vous!</a></button></p>
            </div><!-- End sidebar -->

          </div><!-- End blog sidebar -->

        </div>
		<br/>
	
      </div>
    </section><!-- End Blog Section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projets\SiteWeb\resources\views/liste_des_pub.blade.php ENDPATH**/ ?>