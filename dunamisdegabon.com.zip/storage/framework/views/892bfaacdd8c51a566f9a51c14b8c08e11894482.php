<?php $__env->startSection('title', 'Inscription'); ?>
<?php $__env->startSection('content'); ?>
 <!-- ======= Breadcrumbs ======= -->
    <section id="contact" class="contact">
      <div class="container">

        <div class="row mt-5 justify-content-center" data-aos="fade-up">
          <div class="col-lg-6">
		  <?php if(session('status')): ?>
				<div class="alert alert-success" style="font-size: 15px; background-color: #328039; color: white">
					<i class="ti-check"></i> <?php echo e(session('status')); ?>

				</div>
			<?php endif; ?>

			<?php if(session('error')): ?>
				<div class="alert alert-danger" style="font-size: 15px;color: white">
					<i class="ti-na"></i> <?php echo e(session('error')); ?>

				</div>
			<?php endif; ?>
		  <div style="background-color:#fff;padding:15px;">
		  <h3 align="center">Choix du profil</h3>
		  </div>
		  <br/>
		    <div class="col-md-12 form-group" style="text-align:center;">
					<p style="text-align:center;"><center><a class="btn btn-primary" href="<?php echo e(route('inscription2')); ?>" style="width:100%;">  CLIENT</a></center></p>
				</div>
				<div class="col-md-12 form-group" style="text-align:center;">
					<p style="text-align:center;"><center><a class="btn btn-success" href="<?php echo e(route('inscription-operateur-mobile')); ?>" style="width:100%;">  OPERATEUR</a></center></p>
				</div>
				<div class="col-md-12 form-group" style="text-align:center;">
					<p style="text-align:center;"><center><a class="btn btn-warning" href="<?php echo e(route('inscription-consultant-mobile')); ?>" style="width:100%;">  CONSULTANT</a></center></p>
				</div>
				<div class="col-md-12 form-group" style="text-align:center;">
					<p style="text-align:center;"><center><a class="btn btn-danger" href="<?php echo e(route('inscription-partenaire-mobile')); ?>" style="width:100%;">  PARTENAIRE</a></center></p>
				</div>
				<div class="col-md-12 form-group" style="text-align:center;">
					<p style="text-align:center;"><center><a class="btn btn-info" href="<?php echo e(route('dashbord')); ?>"> Retourner à l'accueil</a></center></p>
				</div>
          </div>
        </div>
      </div>
    </section><!-- End Contact Section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout4', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/c1302473c/public_html/dunamisdegabon.com/resources/views/inscription-mobile.blade.php ENDPATH**/ ?>