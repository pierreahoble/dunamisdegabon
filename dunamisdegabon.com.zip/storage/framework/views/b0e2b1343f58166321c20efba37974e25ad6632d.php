<?php echo e($slot); ?>

<?php /**PATH /home/c1302473c/public_html/dunamisdegabon.com/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>