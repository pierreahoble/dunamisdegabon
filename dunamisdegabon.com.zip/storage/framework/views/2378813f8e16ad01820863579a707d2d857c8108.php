<?php $__env->startSection('title','Liste des clients '); ?>
<?php $__env->startSection('content'); ?>
<!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Liste des clients</h2>
          <ol>
            <li>
			<?php if(session('user')->roles == "Admin"): ?> 
            <a href="<?php echo e(route('tableau_de_bord')); ?>">Tableau de bord</a>
		<?php elseif(session('user')->roles == "Client"): ?> 
		    <a href="<?php echo e(route('tableaudebord')); ?>">Tableau de bord</a>
		<?php else: ?>
			<a href="<?php echo e(route('tb_de_bord')); ?>">Tableau de bord</a>
		<?php endif; ?>
			</li>
            <li>Liste des clients</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->
	     <section id="features" class="features">
      <div class="container" data-aos="fade-up">

        <div class="row">
	<?php if(session('status')): ?>
		<div class="col-lg-12">
            <div class="alert alert-warning" style="font-size: 15px; background-color: #328039; color: white">
                <i class="fa fa-warning"></i> <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger" style="font-size: 15px; background-color: #fb5757; color: white">
                <i class="ti-na"></i> <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger" style="font-size: 15px; background-color: #fb5757; color: white" >
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li> <i class="ti-na"></i> <?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
			</div>
        <?php endif; ?>
		
	<div class="col-lg-12 card">
	        <br>
			<h3>
             <i class="icofont-bars"></i> &nbsp;Liste des clients
            </h3>
			 <br>
            <div class="table-responsive table-hover container">
				<table border="1" style="width:1300px;">
				    <thead>
						<tr>
							<th width="220px" style="text-align:center;">N°</th>
							<th width="320px" style="text-align:center;">Nom</th>
							<th width="320px" style="text-align:center;">Prénoms</th>
							<th width="300px" style="text-align:center;">Téléphone</th>
							<th width="300px" style="text-align:center;">Email</th>
							<th width="300px" style="text-align:center;">Date inscription</th>
							<th width="300px" style="text-align:center;">Nombre d'amis invité</th>
							<th width="300px" style="text-align:center;">Actions</th>
						</tr>
					</thead>
					<tbody>
					<?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clients): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
					<td style="text-align:center;"><?php echo e($loop->iteration); ?></td>
					<td style="text-align:center;"><?php echo e($clients->nom); ?></td>
					<td style="text-align:center;"><?php echo e($clients->prenoms); ?></td>
					<td style="text-align:center;"><?php echo e($clients->telephone); ?></td>
					<td style="text-align:center;"><?php echo e(DB::table('users')->where('id', $clients->users_id)->first()->email); ?></td>
					<td style="text-align:center;"><?php echo e($clients->date_venue); ?></td>
					<td style="text-align:center;"><?php echo e(DB::table('parrainage')->where('parrain_id', $clients->users_id)->get()->count()); ?></td>
					<td>
					</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>	
            </div>
			<div class="blog-pagination">
              <?php echo e($client->links()); ?>

            </div>
	</div>
	      </div>
		  <div class="modal fade bd-example-modal-sm" id="Validermodal">
			<div class="modal-dialog modal-sm">
				<div class="modal-content">
					<div class="modal-body">
						<p>Etes-vous sûr de vouloir valider cette inscription ?<br/>
						Cela stipule qu'un compte sera généré automatiquement pour cet opérateur
						</p>
					</div>
					<div class="modal-footer" style="background-color:#ffffff" id="valider">
	
					</div>
				</div>
			</div>
	</div>
    </section>
	<?php $__env->startPush('scripts'); ?>
	<script>

           

            $(".data-valider").on('click', function () {
                    var id=$(this).data('id');
                    $.get('Operateurs/'+id, function (data) {
                    
                        var html = ` 
                        
                        <button type="button" class="btn btn-sm btn btn-primary" data-dismiss="modal">Non</button>
                            <form action="<?php echo e(route('validercompte')); ?>" method="post" style="display: inline">
                                    <?php echo e(csrf_field()); ?>

                                            <input type="hidden" value="`+data.operateurs.id+`" name="id" >
                            <button type="submit" class="btn btn-sm btn btn-danger">Oui</button>

                        </form>`
                        ;

                        $('#valider').html('').append(html);

                    })
                    $('#Validermodal').modal();
                });

    
    
    </script>
	<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projets\dunamisdegabon.com\resources\views/liste-des-clients.blade.php ENDPATH**/ ?>