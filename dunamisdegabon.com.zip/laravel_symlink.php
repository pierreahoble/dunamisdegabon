<?php
	
	//supprimer le dossier storage qui se trouve le public avant de ...
    symlink('/home/c1302473c/public_html/dunamisdegabon.com/storage/app/public', '/home/c1302473c/public_html/dunamisdegabon.com/public/storage');

?>