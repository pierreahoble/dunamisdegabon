@extends('layout2')
@section('title','Liste des abonnements ')
@section('content')
<!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbss">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Liste des abonnements</h2>
          <ol>
            <li>
			@if (session('user')->roles == "Admin") 
            <a href="{{route('tableau_de_bord')}}">Tableau de bord</a>
		@elseif (session('user')->roles == "Client") 
		    <a href="{{route('tableaudebord')}}">Tableau de bord</a>
		@else
			<a href="{{route('tb_de_bord')}}">Tableau de bord</a>
		@endif
			</li>
            <li>Liste des abonnements</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->
	     <section id="features" class="features">
      <div class="container" data-aos="fade-up">

        <div class="row">
	@if (session('status'))
            <div class="alert alert-warning" style="font-size: 15px; background-color: #328039; color: white">
                <i class="fa fa-warning"></i> {{ session('status') }}
            </div>
        @endif

        @if (session('error'))
            <div class="alert alert-danger" style="font-size: 15px; background-color: #fb5757; color: white">
                <i class="ti-na"></i> {{ session('error') }}
            </div>
        @endif
        @if ($errors->any())
            <div class="alert alert-danger" style="font-size: 15px; background-color: #fb5757; color: white" >
                <ul>
                    @foreach ($errors->all() as $error)
                        <li> <i class="ti-na"></i> {{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
	<div class="col-lg-12 card">
	        <br>
			<h2 align="center">
             Liste des abonnements
            </h2>
			 <br>
            <div class="table-responsive table-hover container">
				<table class="table">
				    <thead>
						<tr>
							<th width="220px">N°</th>
							<th width="220px">Nom & Prénoms</th>
							<th width="300px">Code client</th>
							<th width="300px">Date abon.</th>
							<th width="300px">Date fin abon.</th>
							<th width="300px">Actions</th>
						</tr>
					</thead>
					<tbody>
					@foreach($abon as $abons)
					<tr>
					<td>{{$loop->iteration}}</td>
					<td>{{DB::table('compte')->where('users_id', $abons->compte_id)->first()->nom}} {{DB::table('compte')->where('users_id', $abons->compte_id)->first()->prenoms}}</td>
					<td>{{$abons->code_client}}</td>
					<td>{{$abons->date_abonnement}}</td>
					<td>{{$abons->date_fin_abonnement}}</td>
					<td></td>
					</tr>
					@endforeach
					</tbody>
				</table>
			</div>	
            </div>
			<div class="blog-pagination">
              {{ $abon->links() }}
            </div>
	</div>
	      </div>
    </section>
@endsection