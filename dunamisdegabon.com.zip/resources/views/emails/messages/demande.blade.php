@component('mail::message')
# Bonjour administrateur
 
Une demande de projet vient d'être enregistré. Veuillez vous connecter pour traiter la demande<br>

Merci.<br>
@endcomponent
