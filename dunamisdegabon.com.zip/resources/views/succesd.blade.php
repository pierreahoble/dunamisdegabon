@extends('layout3')
@section('title', 'Succès demande')
@section('content')
 <!-- ======= Breadcrumbs ======= -->
   <!-- End Breadcrumbs --><br/><br/><br/><br/>
    <section id="contact" class="contact">
      <div class="container">

        <div class="row mt-10 justify-content-center" data-aos="fade-up">
          
		
		<div class="col-md-10" style="padding:20px;background-color:#fff;width:100%;height:400px;border:5px;">
		<br/><br/><br/><br/><br/><br/>
		<div class="section-header text-center" style="padding-top: 50px">
		  <p>
		  Votre demande a été bien reçue. Nous vous recontacterons par mail dès qu'elle sera traitée et prise en compte.
		  
		  </p>
         
        </div>
        </div>
		</div>
      </div>
    </section><!-- End Contact Section -->
@endsection
