@extends('layout2')
@section('title','Liste des clients ')
@section('content')
<!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbss">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Liste des clients</h2>
          <ol>
            <li>
			@if (session('user')->roles == "Admin") 
            <a href="{{route('tableau_de_bord')}}">Tableau de bord</a>
		@elseif (session('user')->roles == "Client") 
		    <a href="{{route('tableaudebord')}}">Tableau de bord</a>
		@else
			<a href="{{route('tb_de_bord')}}">Tableau de bord</a>
		@endif
			</li>
            <li>Liste des clients</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->
	     <section id="features" class="features">
      <div class="container" data-aos="fade-up">

        <div class="row">
	@if (session('status'))
            <div class="alert alert-warning" style="font-size: 15px; background-color: #328039; color: white">
                <i class="fa fa-warning"></i> {{ session('status') }}
            </div>
        @endif

        @if (session('error'))
            <div class="alert alert-danger" style="font-size: 15px; background-color: #fb5757; color: white">
                <i class="ti-na"></i> {{ session('error') }}
            </div>
        @endif
        @if ($errors->any())
            <div class="alert alert-danger" style="font-size: 15px; background-color: #fb5757; color: white" >
                <ul>
                    @foreach ($errors->all() as $error)
                        <li> <i class="ti-na"></i> {{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
	<div class="col-lg-12 card">
	        <br>
			<h2 align="center">
             Liste des clients
            </h2>
			 <br>
            <div class="table-responsive table-hover container">
				<table class="table">
				    <thead>
						<tr>
							<th width="220px">N°</th>
							<th width="220px">Nom & Prénoms</th>
							<th width="300px">Email</th>
							<th width="300px">Date entrée</th>
							<th width="300px">Invité(s)</th>
						</tr>
					</thead>
					<tbody>
					@foreach($cli as $clis)
					<tr>
					<td>{{$loop->iteration}}</td>
					<td>{{$clis->nom}} {{$clis->prenoms}}</td>
					<td>{{DB::table('users')->where('id', $clis->users_id)->first()->email}}</td>
					<td>{{$clis->date_venue}}</td>
					<td>{{DB::table('parrainage')->where('parrain_id', $clis->users_id)->count()}}</td>
					</tr>
					@endforeach
					</tbody>
				</table>
			</div>	
            </div>
			<div class="blog-pagination">
              {{ $cli->links() }}
            </div>
	</div>
	      </div>
    </section>
@endsection